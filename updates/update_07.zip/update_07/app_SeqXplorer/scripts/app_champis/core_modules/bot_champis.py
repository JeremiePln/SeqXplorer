import time
import re
import logging
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

def setup_logger(patient_id, log_file_path):
    """Récupère le logger du patient pour y ajouter les logs du bot KNAW"""
    logger = logging.getLogger(f"Logger_{patient_id}")
    if not logger.handlers:
        fh = logging.FileHandler(log_file_path, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    return logger

def extract_species(ref_clean):
    text = re.sub(r'\s+', ' ', ref_clean).strip()
    chunks = [c.strip() for c in text.split(',') if c.strip()]
    if not chunks:
        return "Inconnu"
        
    first_chunk = chunks[0]
    
    if first_chunk.lower() == "fungi":
        last_node = chunks[-1] 
        words = last_node.split()
        if len(words) >= 2 and words[0][0].isupper():
            return f"{words[0]} {words[1]} *"
        else:
            return f"{last_node} *"
            
    words = first_chunk.split()
    if len(words) >= 2:
        return f"{words[0]} {words[1]}"
        
    return first_chunk

def summarize_champis_hits(hits):
    if not hits:
        return []
        
    for h in hits:
        clean_sim = h["Similarity"].replace('%', '').strip()
        try:
            h["sim_val"] = float(clean_sim)
        except ValueError:
            h["sim_val"] = 0.0
            
    max_sim = max(hits, key=lambda x: x["sim_val"])["sim_val"]
    top_hits = [h for h in hits if h["sim_val"] == max_sim]
    
    species_count = {}
    for h in top_hits:
        sp_name = extract_species(h["Ref_Clean"])
        species_count[sp_name] = species_count.get(sp_name, 0) + 1
        
    summary = []
    for sp, count in species_count.items():
        summary.append({
            "Species": sp,
            "Max_Similarity": f"{max_sim}%",
            "Occurrences": count
        })
        
    summary.sort(key=lambda x: x["Occurrences"], reverse=True)
    return summary

def fetch_knaw_alignment(consensus_fasta_path, patient_id):
    out_dir = Path(consensus_fasta_path).parent.parent
    log_file = out_dir / f"pipeline_{patient_id}.log"
    logger = setup_logger(patient_id, log_file)
    logger.info("--- Démarrage du Bot Playwright : Alignement KNAW (Iframe & Ordre Strict) ---")
    
    results = {
        "status": "success",
        "error_msg": "",
        "summary": [],
        "hits": []
    }
    
    try:
        with open(consensus_fasta_path, "r") as f:
            sequence = "".join([line.strip() for line in f.readlines() if not line.startswith(">")])
        logger.info("Séquence consensus chargée en mémoire.")
    except Exception as e:
        err = f"Erreur FASTA : {e}"
        logger.error(err)
        results["status"] = "error"
        results["error_msg"] = err
        return results

    logger.info("Ouverture du navigateur...")
    with sync_playwright() as p:
        # Toujours en False pour visualiser l'enchaînement
        browser = p.chromium.launch(headless=True) 
        context = browser.new_context(viewport={'width': 1920, 'height': 1080})
        page = context.new_page()

        try:
            logger.info("Navigation vers le portail Westerdijk (KNAW)...")
            page.goto("https://wi.knaw.nl/Pairwise_alignment", timeout=90000)
            
            # --- ÉTAPE 0 : Cookies ---
            try:
                page.get_by_text("Allow cookies", exact=False).click(timeout=3000)
                logger.info("Bannière de cookies acceptée.")
            except Exception:
                pass
            
            logger.info("Ciblage de l'Iframe interne (DNA Predict)...")
            frame = page.frame_locator("iframe[title='DNA Predict']")
            
            # --- ÉTAPE 1 : Disclaimer ---
            logger.info("Validation du disclaimer...")
            label = frame.locator("label[for='disclaimer-consent']").first
            label.wait_for(state="attached", timeout=15000)
            label.evaluate("node => node.click()")
            time.sleep(1)
            
            # --- ÉTAPE 2 : Injection ---
            logger.info("Injection de la séquence par contournement DOM...")
            textarea = frame.locator("textarea").first
            textarea.wait_for(state="attached", timeout=10000)
            
            logger.info("Validation du disclaimer...")
            label = frame.locator("label[for='disclaimer-consent']").first
            label.wait_for(state="attached", timeout=15000)
            label.evaluate("node => node.click()")
            time.sleep(1)

            # Utilisation combinée de Playwright et de JS pour forcer la reconnaissance du texte
            textarea.fill(sequence, force=True)
            textarea.evaluate(
                "(el) => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }"
            )
            time.sleep(1)
            
            # --- ÉTAPE 3 : Clic sur Next ---
            logger.info("Clic sur le bouton 'Next'...")
            next_btn = frame.locator("button:has-text('Next')").first
            next_btn.wait_for(state="attached", timeout=10000)
            next_btn.evaluate("btn => { btn.disabled = false; btn.click(); }")
            time.sleep(1.5)
            
            # --- ÉTAPE 4 : Run in parallel ---
            logger.info("Lancement de l'analyse via 'Run in parallel'...")
            run_btn = frame.locator("button:has-text('Run in parallel')").first
            run_btn.wait_for(state="attached", timeout=15000)
            run_btn.evaluate("btn => { btn.disabled = false; btn.click(); }")
            
            # --- ÉTAPE 5 : Récupération du tableau de résultats ---
            start_time = time.time()
            logger.info("Attente des résultats (Timeout de sécurité fixé à 160 secondes)...")
            
            try:
                frame.locator("th:has-text('Similarity')").wait_for(state="visible", timeout=160000)
            except PlaywrightTimeoutError:
                logger.warning("Le tableau n'est pas apparu dans le délai imparti.")
            
            previous_row_count = 0
            stable_checks = 0
            
            logger.info("Scraping du nouveau tableau de résultats en cours...")
            for tentative in range(80): 
                if time.time() - start_time >= 160:
                    break
                    
                time.sleep(2) 
                current_rows = frame.locator("tbody tr").all()
                current_count = len(current_rows)
                
                if current_count > 0:
                    if current_count == previous_row_count:
                        stable_checks += 1
                    else:
                        stable_checks = 0 
                        
                    if stable_checks >= 5:
                        break
                        
                previous_row_count = current_count
                
            extracted_hits = []
            rows = frame.locator("tbody tr").all()
                
            for row in rows:
                cols = row.locator("td").all()
                    
                if len(cols) >= 9:
                    match_id = cols[1].inner_text().strip()
                    
                    species_link = cols[2].locator("a").first
                    if species_link.count() > 0:
                        species_name = species_link.inner_text().strip()
                    else:
                        species_name = cols[2].inner_text().split('\n')[0].strip()
                    
                    raw_sim = cols[4].inner_text()
                    sim_match = re.search(r'([\d\.]+%)', raw_sim)
                    clean_sim = sim_match.group(1) if sim_match else raw_sim.strip()

                    hit = {
                        "Reference": match_id,
                        "Ref_Clean": species_name,
                        "Similarity": clean_sim,   
                        "Overlap": cols[5].inner_text().strip(),
                        "Probability": cols[6].inner_text().strip(),
                        "Score": cols[7].inner_text().strip(),
                        "Rating": cols[8].inner_text().strip()
                    }
                    extracted_hits.append(hit)
            
            if not extracted_hits:
                logger.error("Aucun hit n'a pu être extrait. Capture d'écran...")
                debug_path = out_dir / f"DEBUG_KNAW_{patient_id}.png"
                page.screenshot(path=str(debug_path), full_page=True)
            else:
                logger.info(f"Extraction réussie : {len(extracted_hits)} hits récupérés.")
            
            results["hits"] = extracted_hits
            results["summary"] = summarize_champis_hits(extracted_hits)
            
        except PlaywrightTimeoutError:
            err = "Impossible d'accéder au site KNAW (Timeout)."
            logger.error(err)
            results["status"] = "error"
            results["error_msg"] = err
        except Exception as e:
            err = f"Erreur d'automatisation KNAW : {e}"
            logger.error(err)
            results["status"] = "error"
            results["error_msg"] = err
        finally:
            logger.info("Fermeture sécurisée du navigateur virtuel.")
            browser.close()
            
    return results