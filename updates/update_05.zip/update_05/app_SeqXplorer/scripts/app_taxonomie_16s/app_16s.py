import streamlit as st
import importlib
import math
import shutil
import os
from pathlib import Path
from app_taxonomie_16s.styles import apply_shared_styles, draw_sidebar

# ==========================================
# CONFIGURATION DE LA PAGE STREAMLIT
# ==========================================
st.set_page_config(page_title="Taxonomie 16S - Diagnostic", page_icon="🧬", layout="wide")

apply_shared_styles()
draw_sidebar() 

st.markdown("""
    <style>
    .main [data-testid="stVerticalBlockBorderWrapper"] [data-testid="element-container"]:has(div[data-testid="stPageLink"]) {
        display: flex !important;
        justify-content: center !important;
        width: 100% !important;
    }
    .main div[data-testid="stPageLink"] {
        display: inline-flex !important;
        justify-content: center !important;
        width: auto !important;
    }
    </style>
""", unsafe_allow_html=True)

st.title("🔎 Diagnostic du Système & Intégrité des Modules")

# 1. Vérification des packages Python obligatoires
st.markdown("### 🐍 Dépendances Python")
packages = {
    "Biopython (Bio)": {"module": "Bio", "install": "pip install -r prerequis/requirements.txt"},
    "ReportLab": {"module": "reportlab", "install": "pip install -r prerequis/requirements.txt"},
    "pyPDF (pypdf)": {"module": "pypdf", "install": "pip install -r prerequis/requirements.txt"},
    "Streamlit": {"module": "streamlit", "install": "pip install -r prerequis/requirements.txt"}
}

all_systems_ready = True
checked_packages = []
for name, info in packages.items():
    try:
        importlib.import_module(info["module"])
        is_installed = True
    except ImportError:
        is_installed = False
        all_systems_ready = False
    checked_packages.append((name, is_installed, info["install"]))

cols = st.columns(len(checked_packages))
for i, (name, is_installed, install_cmd) in enumerate(checked_packages):
    with cols[i]:
        if is_installed:
            st.success(f"✅ {name}")
        else:
            st.error(f"🚩 {name}\n\n`{install_cmd}`")

# 2. Vérification de l'exécutable Blast+ et de la base Emu (chemins robustes multi-niveaux)
st.markdown("### 🗄️ Outils Systèmes & Base Curatée Emu (Optionnels)")
col_tools1, col_tools2 = st.columns(2)

current_dir = Path(__file__).resolve().parent # app_taxonomie_16s
exe_name = "blastn.exe" if os.name == "nt" else "blastn"

possible_bin_paths = [
    current_dir.parent.parent / "bin" / exe_name,          # SeqXplorer/bin
    current_dir.parent.parent.parent / "bin" / exe_name,   # Racine plus haute si besoin
    current_dir.parent / "bin" / exe_name,                 # app_SeqXplorer/bin
    Path("bin") / exe_name
]

local_blastn = None
for b_path in possible_bin_paths:
    if b_path.exists():
        local_blastn = b_path
        break

system_blast = shutil.which("blastn")
blastn_ready = local_blastn is not None or system_blast is not None

possible_db_paths = [
    current_dir.parent.parent / "databases" / "emu_db_blast",       # SeqXplorer/databases
    current_dir.parent.parent.parent / "databases" / "emu_db_blast",
    current_dir.parent / "databases" / "emu_db_blast",              # app_SeqXplorer/databases
    current_dir.parent / "emu_db_blast"
]

db_path = None
for p in possible_db_paths:
    if p.exists():
        db_path = p
        break

db_exists = False
if db_path:
    db_exists = any(f.suffix in ['.nhr', '.nin', '.nsq'] for f in db_path.iterdir() if f.is_file())

with col_tools1:
    if blastn_ready:
        st.success("✅ **NCBI BLAST+ (`blastn`)** opérationnel.")
    else:
        st.warning("⚠️ **NCBI BLAST+** introuvable. (Mode Web uniquement)")

with col_tools2:
    if db_exists:
        st.success(f"✅ **Base Emu locale** détectée : `{db_path.name}`")
    else:
        st.warning("⚠️ **Base Emu locale** introuvable. (Mode Web uniquement)")

if not blastn_ready or not db_exists:
    st.info("💡 **Note :** L'installation locale de BLAST+ ou de la base Emu est incomplète. Le module d'identification locale Emu est désactivé. **Le pipeline continuera automatiquement via les requêtes web vers le NCBI (16S et nt).**")

st.divider()

st.markdown(
    """
    <div style="text-align: center; margin-top: 20px; margin-bottom: 20px;">
        <h2 style="margin-bottom: 5px;">🧬 Plateforme d'Identification Taxonomique Bacterienne 16S</h2>
    </div>
    """, 
    unsafe_allow_html=True
)

dir_notice_16s = Path(__file__).resolve().parent / "Notice 16S"
pdf_notice_path = dir_notice_16s / "Notice d'utilisation 16S nowf.pdf"
img_workflow_path = dir_notice_16s / "Workflow 16S CHU Liege.png"

with st.expander("📖 Consulter la Notice d'Utilisation du module 16S", expanded=False):
    if pdf_notice_path.exists():
        try:
            import base64
            with open(pdf_notice_path, "rb") as f:
                base64_pdf_notice = base64.b64encode(f.read()).decode('utf-8')
            st.markdown(f'<iframe src="data:application/pdf;base64,{base64_pdf_notice}" width="100%" height="600" type="application/pdf"></iframe>', unsafe_allow_html=True)
        except Exception:
            pass
    if img_workflow_path.exists():
        st.image(str(img_workflow_path), caption="Workflow technique - CHU de Liège", width=700)

st.divider()

if all_systems_ready:
    col1, col_center, col3 = st.columns([2, 2, 2])
    with col_center:
        st.page_link("app_taxonomie_16s/pages/1_Analyse_16s.py", label="🚀 Nouvelle Analyse 16S")
else:
    st.error("⚠️ Action impossible : certains composants critiques requis (librairies Python) sont manquants.")