import hashlib
import json
import logging
import re
import socket
import time
from collections import defaultdict
from io import StringIO
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from Bio.Blast import NCBIXML


NCBI_BLAST_URL = "https://blast.ncbi.nlm.nih.gov/Blast.cgi"
NETWORK_TIMEOUT_SECONDS = 45
POLL_INTERVAL_SECONDS = 60
RID_VALIDITY_SECONDS = 23 * 60 * 60
MAX_WAIT_16S_SECONDS = 2 * 60 * 60
MAX_WAIT_NT_SECONDS = 4 * 60 * 60


def setup_logger(patient_id, log_file_path):
    """Initialise un journal propre au run et au dossier du patient."""
    log_path = Path(log_file_path).resolve()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger_name = f"SeqXplorer.BLAST.{patient_id}.{hashlib.sha256(str(log_path).encode()).hexdigest()[:12]}"
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Streamlit conserve les loggers entre deux analyses. Fermer tout ancien
    # gestionnaire empêche qu'un patient réanalysé écrive dans le run précédent.
    for old_handler in list(logger.handlers):
        logger.removeHandler(old_handler)
        old_handler.close()

    handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    formatter = logging.Formatter(
        "%(asctime)s - [%(levelname)s] - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger


def close_logger(logger):
    """Vide et ferme les fichiers de journal à la fin de chaque patient."""
    for handler in list(logger.handlers):
        try:
            handler.flush()
        finally:
            logger.removeHandler(handler)
            handler.close()


def parse_blast_record(blast_record):
    hits = []
    query_len = blast_record.query_length

    for alignment in blast_record.alignments:
        for hsp in alignment.hsps:
            ident_pct = (
                (hsp.identities / hsp.align_length) * 100
                if hsp.align_length > 0
                else 0
            )
            query_span = hsp.query_end - hsp.query_start + 1
            query_cover = (query_span / query_len) * 100 if query_len > 0 else 0

            raw_title = alignment.title
            parts = raw_title.split("|")
            clean_name = parts[-1].strip() if len(parts) > 1 else raw_title

            hits.append(
                {
                    "Accession": alignment.accession,
                    "Name": clean_name,
                    "RawTitle": raw_title,
                    "Identity": round(ident_pct, 2),
                    "QueryCover": round(query_cover, 2),
                    "E_value": hsp.expect,
                }
            )
            break

        if len(hits) >= 100:
            break

    return hits


def summarize_hits(hits):
    species_stats = defaultdict(list)

    for hit in hits:
        clean_name = re.sub(r"[\[\]']", "", hit["Name"])
        words = clean_name.split()
        if not words:
            continue
        species_name = f"{words[0]} {words[1]}" if len(words) >= 2 else words[0]
        species_stats[species_name].append(hit["Identity"])

    summary = []
    for species_name, identities in species_stats.items():
        max_identity = max(identities)
        summary.append(
            {
                "Species": species_name,
                "Max_Identity": max_identity,
                "Occurrences": identities.count(max_identity),
            }
        )

    summary.sort(
        key=lambda item: (item["Max_Identity"], item["Occurrences"]),
        reverse=True,
    )
    return summary[:5]


def _request_ncbi(parameters, logger, operation, retry_count=3):
    """Envoie une requête NCBI avec un timeout réseau et des reprises bornées."""
    payload = urlencode(parameters).encode("ascii")
    request = Request(
        NCBI_BLAST_URL,
        data=payload,
        headers={"User-Agent": "SeqXplorer/1.0"},
    )

    for attempt in range(1, retry_count + 1):
        try:
            with urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS) as response:
                return response.read()
        except HTTPError as exc:
            retryable = exc.code == 429 or 500 <= exc.code < 600
            details = exc.read().decode("utf-8", errors="replace")[:300]
            logger.warning(
                "%s : erreur HTTP %s (tentative %s/%s). %s",
                operation,
                exc.code,
                attempt,
                retry_count,
                details,
            )
            if not retryable or attempt == retry_count:
                raise RuntimeError(
                    f"NCBI a renvoyé l'erreur HTTP {exc.code} pendant {operation}."
                ) from exc
        except (URLError, TimeoutError, socket.timeout) as exc:
            logger.warning(
                "%s : erreur réseau ou timeout (tentative %s/%s) : %s",
                operation,
                attempt,
                retry_count,
                exc,
            )
            if attempt == retry_count:
                raise RuntimeError(
                    f"Connexion au NCBI impossible pendant {operation} : {exc}"
                ) from exc

        time.sleep(5 * attempt)

    raise RuntimeError(f"Échec inattendu pendant {operation}.")


def _extract_submission_details(response_bytes):
    response_text = response_bytes.decode("utf-8", errors="replace")
    rid_match = re.search(r"^\s*RID\s*=\s*(\S+)", response_text, re.MULTILINE)
    rtoe_match = re.search(r"^\s*RTOE\s*=\s*(\d+)", response_text, re.MULTILINE)

    if not rid_match:
        error_match = re.search(
            r"(?:Message ID#[^<\r\n]*|<div[^>]*class=[\"']error[^>]*>(.*?)</div>)",
            response_text,
            re.IGNORECASE | re.DOTALL,
        )
        message = re.sub(r"<[^>]+>", " ", error_match.group(0)).strip() if error_match else ""
        if message:
            raise RuntimeError(f"Soumission refusée par le NCBI : {message[:300]}")
        raise RuntimeError(
            "Le NCBI n'a pas renvoyé d'identifiant RID pour la recherche BLAST."
        )

    rid = rid_match.group(1)
    rtoe = int(rtoe_match.group(1)) if rtoe_match else 20
    return rid, rtoe


def _extract_status(response_bytes):
    response_text = response_bytes.decode("utf-8", errors="replace")
    status_match = re.search(
        r"^\s*Status\s*=\s*([A-Za-z]+)", response_text, re.MULTILINE
    )
    return status_match.group(1).upper() if status_match else None


def _sequence_digest(sequence_data):
    return hashlib.sha256(sequence_data.encode("ascii")).hexdigest()


def _load_rid_state(state_path, database, sequence_hash, logger):
    """Recharge uniquement un RID encore valide pour la même séquence et base."""
    if not state_path.exists():
        return None

    try:
        with open(state_path, "r", encoding="utf-8") as state_file:
            state = json.load(state_file)
    except (OSError, ValueError, TypeError) as exc:
        logger.warning("Etat RID illisible (%s) : %s", state_path.name, exc)
        return None

    if state.get("database") != database or state.get("sequence_hash") != sequence_hash:
        logger.info("Etat RID ignoré : la base ou la séquence a changé.")
        return None

    submitted_at = state.get("submitted_at")
    if not isinstance(submitted_at, (int, float)):
        return None
    if (
        state.get("status") != "READY"
        and time.time() - submitted_at >= RID_VALIDITY_SECONDS
    ):
        logger.info("RID précédent expiré : une nouvelle recherche sera soumise.")
        return None

    rid = state.get("rid")
    return state if isinstance(rid, str) and rid.strip() else None


def _save_rid_state(state_path, state):
    """Ecrit l'état de façon atomique pour résister à un arrêt de l'application."""
    temporary_path = state_path.with_name(f"{state_path.name}.tmp")
    with open(temporary_path, "w", encoding="utf-8") as state_file:
        json.dump(state, state_file, ensure_ascii=False, indent=2)
    temporary_path.replace(state_path)


def _parse_result_xml(result_bytes, rid):
    xml_text = result_bytes.decode("utf-8", errors="replace")
    if "<BlastOutput" not in xml_text:
        raise RuntimeError(
            f"Le NCBI n'a pas renvoyé un résultat XML valide pour RID={rid}."
        )
    return NCBIXML.read(StringIO(xml_text))


def run_ncbi_blast(
    database,
    sequence_data,
    email,
    logger,
    label,
    max_wait_seconds,
    state_path,
    result_path,
):
    """Soumet ou reprend un RID, puis récupère le résultat NCBI."""
    submit_parameters = {
        "CMD": "Put",
        "PROGRAM": "blastn",
        "DATABASE": database,
        "QUERY": sequence_data,
        "HITLIST_SIZE": 100,
        "MEGABLAST": "off",
        "WORD_SIZE": 11,
        "email": email,
        "tool": "SeqXplorer",
    }

    logger.info(
        "%s : base=%s | programme=blastn standard | MegaBLAST=off | word size=11",
        label,
        database,
    )

    state_path = Path(state_path)
    result_path = Path(result_path)
    sequence_hash = _sequence_digest(sequence_data)
    state = _load_rid_state(state_path, database, sequence_hash, logger)

    if state and state.get("status") == "READY" and result_path.exists():
        logger.info("%s : réutilisation du résultat local %s.", label, result_path.name)
        return _parse_result_xml(result_path.read_bytes(), state["rid"])

    if state:
        rid = state["rid"]
        estimated_seconds = POLL_INTERVAL_SECONDS
        logger.info("%s : reprise du RID existant %s, sans nouvelle soumission.", label, rid)
    else:
        # Une soumission n'est jamais répétée automatiquement en cas de
        # timeout réseau : le serveur pourrait avoir créé un RID sans que sa
        # réponse nous soit parvenue.
        submission = _request_ncbi(
            submit_parameters,
            logger,
            f"soumission {label}",
            retry_count=1,
        )
        rid, estimated_seconds = _extract_submission_details(submission)
        state = {
            "rid": rid,
            "database": database,
            "sequence_hash": sequence_hash,
            "submitted_at": time.time(),
            "last_poll_at": 0,
            "status": "WAITING",
        }
        _save_rid_state(state_path, state)
        logger.info(
            "%s soumis avec succès. RID=%s | estimation NCBI=%ss",
            label,
            rid,
            estimated_seconds,
        )

    started_at = time.monotonic()
    last_poll_at = float(state.get("last_poll_at", 0) or 0)
    if last_poll_at:
        initial_wait = max(0, POLL_INTERVAL_SECONDS - (time.time() - last_poll_at))
    else:
        initial_wait = max(POLL_INTERVAL_SECONDS, min(estimated_seconds, 300))
    if initial_wait > 0:
        logger.info("%s : prochaine vérification dans %ss.", label, int(initial_wait))
        time.sleep(initial_wait)

    while True:
        elapsed = time.monotonic() - started_at
        status_response = _request_ncbi(
            {
                "CMD": "Get",
                "RID": rid,
                "FORMAT_OBJECT": "SearchInfo",
                "email": email,
                "tool": "SeqXplorer",
            },
            logger,
            f"vérification du RID {rid}",
        )
        status = _extract_status(status_response)
        state["last_poll_at"] = time.time()
        state["status"] = status or "INDETERMINE"
        _save_rid_state(state_path, state)
        logger.info(
            "%s : statut NCBI=%s | RID=%s | attente=%ss",
            label,
            status or "INDETERMINE",
            rid,
            int(elapsed),
        )

        if status == "READY":
            break
        if status in {"FAILED", "UNKNOWN"}:
            raise RuntimeError(f"Le NCBI a renvoyé le statut {status} pour RID={rid}.")
        if status != "WAITING":
            raise RuntimeError(
                f"Réponse de statut NCBI non reconnue pour RID={rid}."
            )

        # Toujours contrôler le statut avant le délai : un job devenu READY
        # à la dernière minute ne doit pas être abandonné sans téléchargement.
        if elapsed >= max_wait_seconds:
            raise TimeoutError(
                f"{label} est toujours en attente au NCBI après "
                f"{int(elapsed)} secondes (RID={rid}). Relancez le même run pour "
                "reprendre ce RID sans soumettre une nouvelle recherche."
            )

        time.sleep(POLL_INTERVAL_SECONDS)

    result_bytes = _request_ncbi(
        {
            "CMD": "Get",
            "RID": rid,
            "FORMAT_TYPE": "XML",
            "ALIGNMENTS": 100,
            "DESCRIPTIONS": 100,
            "email": email,
            "tool": "SeqXplorer",
        },
        logger,
        f"téléchargement des résultats {label}",
    )
    blast_record = _parse_result_xml(result_bytes, rid)
    result_path.write_bytes(result_bytes)
    state["status"] = "READY"
    state["completed_at"] = time.time()
    _save_rid_state(state_path, state)

    logger.info("%s : résultat XML récupéré. RID=%s", label, rid)
    return blast_record


def _read_consensus_sequence(consensus_fasta_path):
    # Lecture binaire pour ignorer l'encodage Windows éventuel de l'en-tête FASTA.
    with open(consensus_fasta_path, "rb") as fasta_file:
        sequence_bytes = b"".join(
            line.strip() for line in fasta_file if not line.startswith(b">")
        )

    try:
        sequence_data = sequence_bytes.decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError(
            "La séquence consensus contient des caractères non valides pour un FASTA ADN."
        ) from exc

    if not sequence_data:
        raise ValueError("La séquence consensus FASTA est vide.")
    return sequence_data


def run_blast_patient(consensus_fasta_path, email, patient_id):
    """Interroge exclusivement les bases distantes NCBI 16S et nt."""
    output_dir = Path(consensus_fasta_path).parent
    log_file = output_dir / f"pipeline_{patient_id}.log"
    logger = setup_logger(patient_id, log_file)

    logger.info(f"========== NOUVELLE ANALYSE PATIENT : {patient_id} ==========")
    logger.info("Fichier journal : %s", log_file.resolve())
    logger.info(f"Email NCBI configuré : {email}")
    logger.info(f"Fichier Consensus : {consensus_fasta_path}")
    logger.info(
        "Mode BLASTN standard distant uniquement via API NCBI avec suivi RID "
        "(MegaBLAST désactivé, word size 11)."
    )

    results = {
        "status": "success",
        "error_msg": "",
        "16S": {"summary": [], "hits": []},
        "nt": {"summary": [], "hits": []},
    }

    try:
        sequence_data = _read_consensus_sequence(consensus_fasta_path)

        logger.info("Lancement de la requête NCBI 16S...")
        blast_record_16s = run_ncbi_blast(
            "rRNA_typestrains/16S_ribosomal_RNA",
            sequence_data,
            email,
            logger,
            "NCBI 16S",
            max_wait_seconds=MAX_WAIT_16S_SECONDS,
            state_path=output_dir / "blast_16S_rid.json",
            result_path=output_dir / "blast_16S_result.xml",
        )
        hits_16s = parse_blast_record(blast_record_16s)
        results["16S"]["hits"] = hits_16s
        results["16S"]["summary"] = summarize_hits(hits_16s)

        logger.info("Requête 16S terminée. Pause de courtoisie de 5s...")
        time.sleep(5)

        logger.info("Lancement de la requête NCBI nr/nt...")
        blast_record_nt = run_ncbi_blast(
            "nt",
            sequence_data,
            email,
            logger,
            "NCBI nr/nt",
            max_wait_seconds=MAX_WAIT_NT_SECONDS,
            state_path=output_dir / "blast_nt_rid.json",
            result_path=output_dir / "blast_nt_result.xml",
        )
        hits_nt = parse_blast_record(blast_record_nt)
        results["nt"]["hits"] = hits_nt
        results["nt"]["summary"] = summarize_hits(hits_nt)
        logger.info("Requête nr/nt terminée avec succès.")
        logger.info("Analyse globale terminée avec succès.")

    except Exception as exc:
        logger.exception(
            "Échec de l'analyse BLAST NCBI pour le patient %s", patient_id
        )
        results["status"] = "error"
        results["error_msg"] = f"{exc} Journal : {log_file.resolve()}"

    finally:
        close_logger(logger)

    return results
