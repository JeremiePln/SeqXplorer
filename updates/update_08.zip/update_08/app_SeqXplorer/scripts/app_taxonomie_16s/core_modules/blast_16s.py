import logging
import re
import time
from collections import defaultdict
from pathlib import Path

from Bio.Blast import NCBIWWW, NCBIXML


def setup_logger(patient_id, log_file_path):
    """Initialise un logger spécifique au patient."""
    logger = logging.getLogger(f"Logger_{patient_id}")
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        handler = logging.FileHandler(log_file_path, encoding="utf-8")
        formatter = logging.Formatter(
            "%(asctime)s - [%(levelname)s] - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


def parse_blast_record(blast_record):
    hits = []
    query_len = blast_record.query_length

    for alignment in blast_record.alignments:
        for hsp in alignment.hsps:
            ident_pct = (
                (hsp.identities / hsp.align_length) * 100
                if hsp.align_length > 0
                else 0
            )
            query_span = hsp.query_end - hsp.query_start + 1
            query_cover = (query_span / query_len) * 100 if query_len > 0 else 0

            raw_title = alignment.title
            parts = raw_title.split("|")
            clean_name = parts[-1].strip() if len(parts) > 1 else raw_title

            hits.append(
                {
                    "Accession": alignment.accession,
                    "Name": clean_name,
                    "RawTitle": raw_title,
                    "Identity": round(ident_pct, 2),
                    "QueryCover": round(query_cover, 2),
                    "E_value": hsp.expect,
                }
            )
            break

        if len(hits) >= 100:
            break

    return hits


def summarize_hits(hits):
    species_stats = defaultdict(list)

    for hit in hits:
        clean_name = re.sub(r"[\[\]']", "", hit["Name"])
        words = clean_name.split()
        if not words:
            continue
        species_name = f"{words[0]} {words[1]}" if len(words) >= 2 else words[0]
        species_stats[species_name].append(hit["Identity"])

    summary = []
    for species_name, identities in species_stats.items():
        max_identity = max(identities)
        summary.append(
            {
                "Species": species_name,
                "Max_Identity": max_identity,
                "Occurrences": identities.count(max_identity),
            }
        )

    summary.sort(
        key=lambda item: (item["Max_Identity"], item["Occurrences"]),
        reverse=True,
    )
    return summary[:5]


def run_blast_patient(consensus_fasta_path, email, patient_id):
    """Interroge exclusivement les bases distantes NCBI 16S et nt."""
    output_dir = Path(consensus_fasta_path).parent
    log_file = output_dir / f"pipeline_{patient_id}.log"
    logger = setup_logger(patient_id, log_file)

    logger.info(f"========== NOUVELLE ANALYSE PATIENT : {patient_id} ==========")
    logger.info(f"Email NCBI configuré : {email}")
    logger.info(f"Fichier Consensus : {consensus_fasta_path}")
    logger.info("Mode BLAST distant uniquement : module local Emu désactivé.")

    NCBIWWW.email = email

    with open(consensus_fasta_path, "r", encoding="utf-8") as fasta_file:
        sequence_data = "".join(
            line.strip() for line in fasta_file if not line.startswith(">")
        )

    results = {
        "status": "success",
        "error_msg": "",
        "16S": {"summary": [], "hits": []},
        "nt": {"summary": [], "hits": []},
    }

    try:
        logger.info("Lancement de la requête NCBI 16S...")
        result_handle_16s = NCBIWWW.qblast(
            "blastn",
            "rRNA_typestrains/prokaryotic_16S_ribosomal_RNA",
            sequence_data,
            hitlist_size=100,
            megablast="off",
            word_size=11,
        )
        try:
            blast_record_16s = NCBIXML.read(result_handle_16s)
        finally:
            result_handle_16s.close()

        hits_16s = parse_blast_record(blast_record_16s)
        results["16S"]["hits"] = hits_16s
        results["16S"]["summary"] = summarize_hits(hits_16s)

        logger.info("Requête 16S terminée. Pause de courtoisie de 5s...")
        time.sleep(5)

        logger.info("Lancement de la requête NCBI nr/nt...")
        result_handle_nt = NCBIWWW.qblast(
            "blastn",
            "nt",
            sequence_data,
            hitlist_size=100,
            megablast="off",
            word_size=11,
        )
        try:
            blast_record_nt = NCBIXML.read(result_handle_nt)
        finally:
            result_handle_nt.close()

        hits_nt = parse_blast_record(blast_record_nt)
        results["nt"]["hits"] = hits_nt
        results["nt"]["summary"] = summarize_hits(hits_nt)
        logger.info("Requête nr/nt terminée avec succès.")
        logger.info("Analyse globale terminée avec succès.")

    except Exception as exc:
        logger.exception(
            "Échec de l'analyse BLAST NCBI pour le patient %s", patient_id
        )
        results["status"] = "error"
        results["error_msg"] = str(exc)

    return results
