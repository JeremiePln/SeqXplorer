import os
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak

def get_clinical_conclusion(summary_16s):
    if not summary_16s:
        return "Aucune identification significative (Aucun hit)."
    
    best_hits = sorted(summary_16s, key=lambda x: x["Max_Identity"], reverse=True)
    max_id = best_hits[0]["Max_Identity"]
    top_species = [s["Species"] for s in best_hits if s["Max_Identity"] == max_id]
    genus = top_species[0].split()[0] if top_species else "Inconnu"
    
    if max_id == 100.0:
        if len(top_species) > 1:
            return f"<b>Identification au genre {genus}</b> : Multiples espèces à 100% ({', '.join(top_species)})."
        else:
            return f"<b>Identification à l'espèce/sous-espèce : {top_species[0]}</b> (100% d'identité)"
    elif max_id >= 99.0:
        if len(top_species) > 1:
            return f"<b>Identification au genre {genus}</b> : Multiples espèces ex-æquo à {max_id}%."
        else:
            return f"<b>Identification à l'espèce : {top_species[0]}</b> ({max_id}% d'identité)"
    elif max_id >= 97.0:
        return f"<b>Identification au genre : {genus} spp.</b> ({max_id}% d'identité)"
    else:
        return f"<b>Identification incertaine</b> (< 97% : {max_id}%)"

def get_header_table(styles):
    try:
        global_root = Path(__file__).resolve().parent.parent.parent.parent
    except Exception:
        global_root = Path(__file__).resolve().parent.parent
    logo_path = global_root / "ressources" / "logo_chu.png"
    logo_img = Image(str(logo_path), width=2.8*cm, height=1.7*cm) if logo_path.exists() else Paragraph("<b>CHU Liege</b>", styles["Normal"])

    header_title_style = ParagraphStyle('HeaderTitle', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=16, textColor=colors.black, alignment=0)
    title_p = Paragraph("RAPPORT DE TAXONOMIE BACTÉRIENNE 16S", header_title_style)

    header_table = Table([[logo_img, title_p]], colWidths=[3*cm, 14*cm])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 2, colors.darkblue),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
    ]))
    return header_table

def create_qc_box(qc_metrics, styles):
    f_q20 = qc_metrics.get("f_q20", 0)
    r_q20 = qc_metrics.get("r_q20", 0)
    f_avg = qc_metrics.get("f_avg_phred", 0)
    r_avg = qc_metrics.get("r_avg_phred", 0)
    conf_rate = qc_metrics.get("conflict_rate", 0)
    conf_count = qc_metrics.get("conflicts", 0)
    
    is_red = f_q20 < 60 or r_q20 < 60 or conf_rate > 5.0
    is_orange = (60 <= f_q20 <= 80) or (60 <= r_q20 <= 80) or (2.0 <= conf_rate <= 5.0)
    
    if is_red:
        title, bg_color, border_color = "🛑 ALERTE QUALITÉ : SOUPÇON DE CONTAMINATION", colors.HexColor("#fdf2f2"), colors.red
    elif is_orange:
        title, bg_color, border_color = "⚠️ QUALITÉ MOYENNE : SÉQUENCE BRUITÉE", colors.HexColor("#fff8e6"), colors.orange
    else:
        title, bg_color, border_color = "✅ QUALITÉ SÉQUENÇAGE : OPTIMALE", colors.HexColor("#f0fdf4"), colors.green

    content = [
        Paragraph(f"<b>{title}</b>", styles["Normal"]),
        Paragraph(f"• F : Q20 = {f_q20:.1f}% (Phred: {f_avg:.1f}) | R : Q20 = {r_q20:.1f}% (Phred: {r_avg:.1f})", styles["Normal"]),
        Paragraph(f"• Conflits F/R résolus : {conf_count} ({conf_rate:.1f}%)", styles["Normal"])
    ]
    t = Table([[c] for c in content], colWidths=[17*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), bg_color),
        ('BOX', (0,0), (-1,-1), 1.5, border_color),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    return t

def create_summary_table(summary_data):
    data = [["Bactérie (Genre Espèce)", "Identité Max (%)", "Occurence(s)"]]
    for item in summary_data:
        data.append([item["Species"], f"{item['Max_Identity']}%", str(item["Occurrences"])])
    t = Table(data, colWidths=[8*cm, 4*cm, 4*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#28a745")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0,0), (-1,0), 6),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
    ]))
    return t

def create_hits_table(hits_data):
    styles = getSampleStyleSheet()
    small_text_style = ParagraphStyle("SmallText", parent=styles["Normal"], fontSize=6, leading=7, textColor=colors.black)
    data = [["Nom complet de la souche", "% Identité", "Query Cover", "E-value", "Accession"]]
    for h in hits_data:
        formatted_e_value = "0.0" if h['E_value'] == 0 else f"{h['E_value']:.2e}"
        data.append([Paragraph(h["Name"], small_text_style), f"{h['Identity']}%", f"{h['QueryCover']}%", formatted_e_value, h["Accession"]])
    t = Table(data, colWidths=[10*cm, 1.8*cm, 1.8*cm, 1.5*cm, 2.2*cm], repeatRows=1) 
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#343a40")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (1,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 3),
    ]))
    return t

def generate_final_report(patient_id, qc_metrics, blast_metrics, output_dir):
    out_path = Path(output_dir)
    final_report_path = out_path / f"Rapport_Final_{patient_id}.pdf"
    
    doc = SimpleDocTemplate(str(final_report_path), pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    subtitle_style = styles["Heading2"]
    subtitle_style.textColor = colors.darkblue
    normal_style = styles["Normal"]
    
    Story = [] 
    
    # ================== PAGE 1 ==================
    Story.append(get_header_table(styles))
    Story.append(Spacer(1, 0.4*cm))
    
    Story.append(Paragraph("INFORMATIONS DE L'ÉCHANTILLON", subtitle_style))
    Story.append(Paragraph(f"<b>Identifiant (Run/Patient) :</b> {patient_id}", normal_style))
    Story.append(Paragraph(f"<b>Longueur du Consensus soumis au BLAST :</b> {qc_metrics.get('len_consensus', 0)} pb", normal_style))
    Story.append(Spacer(1, 0.2*cm))
    
    Story.append(Paragraph("CONTRÔLE QUALITÉ DU SÉQUENÇAGE", subtitle_style))
    Story.append(create_qc_box(qc_metrics, styles))
    Story.append(Spacer(1, 0.3*cm))
    
    Story.append(Paragraph("CONCLUSIONS CLINIQUES", subtitle_style))
    
    conc_16s = get_clinical_conclusion(blast_metrics["16S"]["summary"])
    t_16s = Table([[Paragraph("<b>Conclusion Base NCBI 16S rRNA :</b>", styles["Normal"])], [Paragraph(conc_16s, styles["Normal"])]], colWidths=[17*cm])
    t_16s.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f8f9fa")), ('BOX', (0,0), (-1,-1), 2, colors.darkred), ('PADDING', (0,0), (-1,-1), 5)]))
    Story.append(t_16s)
    Story.append(Spacer(1, 0.15*cm))
    
    conc_nt = get_clinical_conclusion(blast_metrics["nt"]["summary"])
    t_nt = Table([[Paragraph("<b>Conclusion Base NCBI Nucléotides (nr/nt) :</b>", styles["Normal"])], [Paragraph(conc_nt, styles["Normal"])]], colWidths=[17*cm])
    t_nt.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f8f9fa")), ('BOX', (0,0), (-1,-1), 2, colors.darkred), ('PADDING', (0,0), (-1,-1), 5)]))
    Story.append(t_nt)
    
    Story.append(PageBreak())
    
    # ================== PAGE 2 ==================
    Story.append(get_header_table(styles))
    Story.append(Spacer(1, 0.4*cm))
    
    Story.append(Paragraph("SYNTHÈSE DES ESPÈCES DOMINANTES (Top 5)", subtitle_style))
    Story.append(Spacer(1, 0.2*cm))
    
    Story.append(Paragraph("<i>Base NCBI 16S Ribosomal RNA</i>", normal_style))
    Story.append(Spacer(1, 0.05*cm))
    Story.append(create_summary_table(blast_metrics["16S"]["summary"]))
    Story.append(Spacer(1, 0.3*cm))
    
    Story.append(Paragraph("<i>Base NCBI Nucléotides (nr/nt)</i>", normal_style))
    Story.append(Spacer(1, 0.05*cm))
    Story.append(create_summary_table(blast_metrics["nt"]["summary"]))
    Story.append(Spacer(1, 0.4*cm))

    Story.append(Paragraph("SÉQUENCE CONSENSUS GÉNÉRÉE :", subtitle_style))
    try:
        with open(qc_metrics["consensus_path"], "r") as f:
            seq_content = "".join([l.strip() for l in f if not l.startswith(">")])
        Story.append(Paragraph(seq_content, ParagraphStyle('SeqStyle', parent=styles['Normal'], fontSize=6, fontName='Courier', leading=9)))
    except Exception:
        pass
        
    Story.append(PageBreak())
    
    # ================== PAGES 3 ET + ==================
    Story.append(Paragraph("TRAÇABILITÉ : BASE NCBI 16S rRNA", subtitle_style))
    Story.append(Spacer(1, 0.3*cm))
    Story.append(create_hits_table(blast_metrics["16S"]["hits"]))
    Story.append(PageBreak())
    
    Story.append(Paragraph("TRAÇABILITÉ : BASE NCBI NR/NT", subtitle_style))
    Story.append(Spacer(1, 0.3*cm))
    Story.append(create_hits_table(blast_metrics["nt"]["hits"]))
    
    doc.build(Story)
    return str(final_report_path)
