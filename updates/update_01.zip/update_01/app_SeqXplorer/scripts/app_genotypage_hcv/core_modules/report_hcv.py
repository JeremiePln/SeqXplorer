import os
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.units import cm
from pypdf import PdfWriter, PdfReader
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from datetime import datetime

def create_qc_box(qc_metrics, styles):
    f_q20 = qc_metrics.get("f_q20", 0)
    r_q20 = qc_metrics.get("r_q20", 0)
    f_avg = qc_metrics.get("f_avg_phred", 0)
    r_avg = qc_metrics.get("r_avg_phred", 0)
    conf_rate = qc_metrics.get("conflict_rate", 0)
    conf_count = qc_metrics.get("conflicts", 0)
    
    is_red = f_q20 < 60 or r_q20 < 60 or conf_rate > 5.0
    is_orange = (60 <= f_q20 <= 80) or (60 <= r_q20 <= 80) or (2.0 <= conf_rate <= 5.0)
    
    if is_red:
        title = "🛑 ALERTE QUALITÉ : SOUPÇON DE CONTAMINATION / BRUIT"
        bg_color = colors.HexColor("#fdf2f2")
        border_color = colors.red
        note = "Note : Les résultats taxonomiques ci-dessous peuvent être biaisés par une séquence polymicrobienne. Vérification manuelle recommandée."
    elif is_orange:
        title = "⚠️ QUALITÉ MOYENNE : SÉQUENCE BRUITÉE"
        bg_color = colors.HexColor("#fff8e6")
        border_color = colors.orange
        note = "Note : Qualité suboptimale détectée. À interpréter avec précaution."
    else:
        title = "✅ QUALITÉ SÉQUENÇAGE : OPTIMALE"
        bg_color = colors.HexColor("#f0fdf4")
        border_color = colors.green
        note = ""

    content = [
        Paragraph(f"<b>{title}</b>", styles["Normal"]),
        Paragraph(f"• F : Q20 = {f_q20:.1f}% (Phred moy: {f_avg:.1f}) | R : Q20 = {r_q20:.1f}% (Phred moy: {r_avg:.1f})", styles["Normal"]),
        Paragraph(f"• Conflits F/R résolus dans le chevauchement : {conf_count} ({conf_rate:.1f}%)", styles["Normal"])
    ]
    if note:
        content.append(Paragraph(f"<i>{note}</i>", ParagraphStyle("small_i", parent=styles["Normal"], fontSize=8, textColor=colors.darkgray)))
    
    t = Table([[c] for c in content], colWidths=[17*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), bg_color),
        ('BOX', (0,0), (-1,-1), 1.5, border_color),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    return t

def create_cover_page(temp_pdf_path, patient_id, qc_metrics, g2p_metrics):
    c = canvas.Canvas(str(temp_pdf_path), pagesize=A4)
    width, height = A4
    styles = getSampleStyleSheet()
    
    try:
        global_root = Path(__file__).resolve().parent.parent.parent.parent
    except Exception:
        global_root = Path(__file__).resolve().parent
        
    logo_path = global_root / "ressources" / "logo_chu.png"
    
    if logo_path.exists():
        try:
            c.drawImage(str(logo_path), 50, height - 90, width=80, height=50, mask='auto')
        except Exception:
            c.setFillColor(colors.darkblue)
            c.rect(50, height - 90, 80, 50, fill=1)
    else:
        c.setFillColor(colors.darkblue)
        c.rect(50, height - 90, 80, 50, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Helvetica-Bold", 10)
        c.drawString(55, height - 70, "CHU Liege")
    
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(150, height - 70, "RAPPORT DE GENOTYPAGE HCV")
    
    c.setLineWidth(2)
    c.setStrokeColor(colors.darkblue)
    c.line(50, height - 110, width - 50, height - 110)
    
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 150, "INFORMATIONS DE L'ECHANTILLON")
    c.setFont("Helvetica", 12)
    c.drawString(50, height - 170, f"Identifiant (Run/Patient) : {patient_id}")
    c.drawString(50, height - 185, f"Longueur du Consensus final soumis : {qc_metrics.get('len_consensus', 0)} pb")
    
    c.setFont("Helvetica-Bold", 14)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 235, "RESULTAT DU GENOTYPAGE (Geno2pheno)")
    
    c.setFillColor(colors.black)
    c.setFont("Helvetica", 12)
    c.drawString(50, height - 260, f"Sous-type predit : ")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(160, height - 260, g2p_metrics.get("subtype", "Erreur"))
    
    c.setFont("Helvetica", 12)
    c.drawString(50, height - 280, f"Fiabilite de l'alignement : ")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(205, height - 280, g2p_metrics.get("confidence", "Erreur"))
    
    # --- ENCADRÉ QUALITÉ (Mix Canvas / Platypus) ---
    y_pos = height - 335
    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(colors.black)
    c.drawString(50, y_pos, "CONTRÔLE QUALITÉ DU SÉQUENÇAGE")
    y_pos -= 10
    
    qc_table = create_qc_box(qc_metrics, styles)
    qc_table.wrapOn(c, width - 100, 200)
    y_pos -= qc_table._height
    qc_table.drawOn(c, 50, y_pos)

    y_pos -= 15
    legend_style = ParagraphStyle("ThresholdLegend", parent=styles["Normal"], fontSize=8, leading=10, textColor=colors.darkgray)
    legend_html = (
        "<i><b>Seuils d'interprétation :</b></i><br/>"
        "<i>• <b>Qualité Optimale (Vert)</b> : Q20 > 80% | Phred moyen > 30 | Conflits < 2%</i><br/>"
        "<i>• <b>Qualité Moyenne (Orange)</b> : Q20 entre 60% et 80% | Phred moyen entre 20 et 30 | Conflits entre 2% et 5%</i><br/>"
        "<i>• <b>Qualité Basse (Rouge)</b> : Q20 < 60% | Phred moyen < 20 | Conflits > 5%</i>"
    )
    p_legend = Paragraph(legend_html, legend_style)
    p_legend.wrapOn(c, width - 100, 100)
    y_pos -= p_legend.height
    p_legend.drawOn(c, 50, y_pos)
    
    y_pos -= 35
    # --- SÉQUENCE CONSENSUS ---
    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(colors.black)
    c.drawString(50, y_pos, "SÉQUENCE CONSENSUS GÉNÉRÉE PAR SEQXPLORER VIA BIOPYTHON :")
    y_pos -= 15

    try:
        with open(qc_metrics["consensus_path"], "r") as f:
            lines = f.readlines()
            seq_content = "".join([l.strip() for l in lines if not l.startswith(">")])

        seq_style = ParagraphStyle('SeqStyle', parent=styles['Normal'], fontSize=8, fontName='Courier', leading=9, textColor=colors.black)
        p_seq = Paragraph(seq_content, seq_style)
        p_seq.wrapOn(c, width - 100, 300) 
        y_pos -= p_seq.height
        p_seq.drawOn(c, 50, y_pos)
    except Exception:
        c.setFont("Helvetica", 10)
        c.drawString(50, y_pos, "Erreur lors de l'extraction de la séquence.")
    
    date_str = datetime.now().strftime("%d/%m/%Y")
    c.setFont("Helvetica-Oblique", 9)
    c.setFillColor(colors.gray)
    c.drawCentredString(width / 2.0, 1.5 * cm, f"Rapport généré automatiquement par SeqXplorer le {date_str}.")
    
    c.save()

def generate_final_report(patient_id, qc_metrics, g2p_metrics, output_dir):
    out_path = Path(output_dir)
    temp_cover_path = out_path / f"temp_cover_{patient_id}.pdf"
    final_report_path = out_path / f"Rapport_Final_{patient_id}.pdf"
    
    create_cover_page(temp_cover_path, patient_id, qc_metrics, g2p_metrics)
    
    merger = PdfWriter()
    merger.append(temp_cover_path)
    
    g2p_pdf_path = g2p_metrics.get("pdf_path")
    if g2p_pdf_path and Path(g2p_pdf_path).exists():
        merger.append(g2p_pdf_path)
        
    with open(final_report_path, "wb") as output_pdf:
        merger.write(output_pdf)
        
    if temp_cover_path.exists():
        os.remove(temp_cover_path)
        
    return str(final_report_path)