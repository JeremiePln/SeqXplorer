import os
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from datetime import datetime

def create_qc_box(qc_metrics, styles):
    f_q20 = qc_metrics.get("f_q20", 0)
    r_q20 = qc_metrics.get("r_q20", 0)
    f_avg = qc_metrics.get("f_avg_phred", 0)
    r_avg = qc_metrics.get("r_avg_phred", 0)
    conf_rate = qc_metrics.get("conflict_rate", 0)
    conf_count = qc_metrics.get("conflicts", 0)
    
    is_red = f_q20 < 60 or r_q20 < 60 or conf_rate > 5.0
    is_orange = (60 <= f_q20 <= 80) or (60 <= r_q20 <= 80) or (2.0 <= conf_rate <= 5.0)
    
    if is_red:
        title = "🛑 ALERTE QUALITÉ : SOUPÇON DE CONTAMINATION / BRUIT"
        bg_color = colors.HexColor("#fdf2f2")
        border_color = colors.red
        note = "Note : Les résultats taxonomiques ci-dessous peuvent être biaisés par une séquence polymicrobienne. Vérification manuelle recommandée."
    elif is_orange:
        title = "⚠️ QUALITÉ MOYENNE : SÉQUENCE BRUITÉE"
        bg_color = colors.HexColor("#fff8e6")
        border_color = colors.orange
        note = "Note : Qualité suboptimale détectée. À interpréter avec précaution."
    else:
        title = "✅ QUALITÉ SÉQUENÇAGE : OPTIMALE"
        bg_color = colors.HexColor("#f0fdf4")
        border_color = colors.green
        note = ""

    content = [
        Paragraph(f"<b>{title}</b>", styles["Normal"]),
        Paragraph(f"• F : Q20 = {f_q20:.1f}% (Phred moy: {f_avg:.1f}) | R : Q20 = {r_q20:.1f}% (Phred moy: {r_avg:.1f})", styles["Normal"]),
        Paragraph(f"• Conflits F/R résolus dans le chevauchement : {conf_count} ({conf_rate:.1f}%)", styles["Normal"])
    ]
    if note:
        content.append(Paragraph(f"<i>{note}</i>", ParagraphStyle("small_i", parent=styles["Normal"], fontSize=8, textColor=colors.darkgray)))
    
    t = Table([[c] for c in content], colWidths=[17*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), bg_color),
        ('BOX', (0,0), (-1,-1), 1.5, border_color),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    return t

def create_summary_table(summary_data):
    data = [["Espèce de Champignon", "Similarité Max", "Occurrence(s) au score max"]]
    for item in summary_data:
        data.append([item["Species"], item['Max_Similarity'], str(item["Occurrences"])])
        
    t = Table(data, colWidths=[8*cm, 4*cm, 5*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#6f42c1")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0,0), (-1,0), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
    ]))
    return t

def format_proba(proba_str):
    if not proba_str: return ""
    try:
        if 'e' in proba_str.lower():
            base, exp = proba_str.lower().split('e')
            return f"{float(base):.2f}e{exp}"
        return f"{float(proba_str):.2e}"
    except: return proba_str

def create_hits_table(hits_data):
    styles = getSampleStyleSheet()
    tech_style = ParagraphStyle("TechStyle", parent=styles["Normal"], fontSize=6, leading=7, textColor=colors.darkgrey)
    species_style = ParagraphStyle("SpeciesStyle", parent=styles["Normal"], fontSize=8, leading=9)
    
    data = [["Description (Référence)", "Score", "Proba.", "Sim.", "Overlap", "Rating"]]
    
    for h in hits_data[:50]:
        full_ref = h.get("Reference", "")
        clean_name = h.get("Ref_Clean", full_ref)
        tech_info = full_ref.replace(clean_name, "").strip()
        
        cell_content = []
        if tech_info:
            cell_content.append(Paragraph(f"<i>{tech_info}</i>", tech_style))
        cell_content.append(Paragraph(clean_name, species_style))
        
        data.append([cell_content, h["Score"], format_proba(h.get("Probability", "")), h["Similarity"], h.get("Overlap", ""), h.get("Rating", "")])
        
    t = Table(data, colWidths=[8*cm, 1.5*cm, 1.8*cm, 1.8*cm, 2*cm, 1.9*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#343a40")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('ALIGN', (0,1), (0,-1), 'LEFT'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    return t

def add_footer_champis(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica-Oblique', 9)
    canvas.setFillColor(colors.gray)
    date_str = datetime.now().strftime("%d/%m/%Y")
    
    # Page 1 = SeqXplorer, Page 2 et + = KNAW
    if doc.page == 1:
        text = f"Rapport généré automatiquement par SeqXplorer le {date_str}."
    else:
        text = f"Tableau de traçabilité extrait depuis KNAW le {date_str}."
        
    canvas.drawCentredString(A4[0] / 2.0, 1.5 * cm, text)
    canvas.restoreState()
    
def generate_final_report(patient_id, qc_metrics, knaw_metrics, output_dir):
    out_path = Path(output_dir)
    final_report_path = out_path / f"Rapport_Final_{patient_id}.pdf"
    
    doc = SimpleDocTemplate(str(final_report_path), pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    
    Story = []
    styles = getSampleStyleSheet()
    
    logo_path = Path(__file__).resolve().parents[3] / "ressources" / "logo_chu.png"
    if logo_path.exists():
        logo_img = Image(str(logo_path), width=2.8*cm, height=1.7*cm)
    else:
        logo_img = Paragraph("<b>CHU Liege</b>", styles["Normal"])

    header_title_style = ParagraphStyle('HeaderTitle', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=16, textColor=colors.black, alignment=0)
    title_p = Paragraph("RAPPORT D'IDENTIFICATION CHAMPIGNONS", header_title_style)

    header_table = Table([[logo_img, title_p]], colWidths=[3*cm, 14*cm])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 2, colors.darkblue),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
    ]))
    Story.append(header_table)
    Story.append(Spacer(1, 1*cm))
    
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Heading2'], fontSize=12, spaceAfter=10, textColor=colors.HexColor("#343a40"))
    normal_style = styles["Normal"]
    
    Story.append(Paragraph("INFORMATIONS DE L'ÉCHANTILLON", subtitle_style))
    Story.append(Paragraph(f"<b>Identifiant (Run/Patient) :</b> {patient_id}", normal_style))
    Story.append(Paragraph(f"<b>Longueur de la séquence soumise :</b> {qc_metrics.get('len_consensus', 0)} pb", normal_style))
    Story.append(Spacer(1, 0.5*cm))
    
    Story.append(Paragraph("CONTRÔLE QUALITÉ DU SÉQUENÇAGE", subtitle_style))
    Story.append(create_qc_box(qc_metrics, styles))
    Story.append(Spacer(1, 0.2*cm))
    
    legend_style = ParagraphStyle("ThresholdLegend", parent=styles["Normal"], fontSize=8, leading=10, textColor=colors.darkgray)
    Story.append(Paragraph("<i><b>Seuils d'interprétation :</b></i>", legend_style))
    Story.append(Paragraph("<i>• <b>Qualité Optimale (Vert)</b> : Q20 > 80% | Phred moyen > 30 | Conflits < 2%</i>", legend_style))
    Story.append(Paragraph("<i>• <b>Qualité Moyenne (Orange)</b> : Q20 entre 60% et 80% | Phred moyen entre 20 et 30 | Conflits entre 2% et 5%</i>", legend_style))
    Story.append(Paragraph("<i>• <b>Qualité Basse (Rouge)</b> : Q20 < 60% | Phred moyen < 20 | Conflits > 5%</i>", legend_style))
    Story.append(Spacer(1, 0.8*cm))
    
    Story.append(Paragraph("SYNTHÈSE CLINIQUE (ESPÈCES À SIMILARITÉ MAXIMALE)", subtitle_style))
    if knaw_metrics["summary"]:
        Story.append(create_summary_table(knaw_metrics["summary"]))
        if any("*" in item["Species"] for item in knaw_metrics["summary"]):
            Story.append(Spacer(1, 0.2*cm))
            warning_style = ParagraphStyle('Warning', parent=styles['Normal'], fontSize=9, textColor=colors.red)
            Story.append(Paragraph("<i>* Taxonomie complexe ou ambiguë renvoyée par la base de données. Veuillez vous référer à la traçabilité détaillée (Page 2) pour valider l'identification.</i>", warning_style))
    else:
        Story.append(Paragraph("Aucune identification significative.", normal_style))
        
    Story.append(Spacer(1, 0.8*cm))
    
    Story.append(Paragraph("SÉQUENCE CONSENSUS GÉNÉRÉE PAR SEQXPLORER VIA BIOPYTHON :", subtitle_style))
    try:
        with open(qc_metrics["consensus_path"], "r") as f:
            lines = f.readlines()
            seq_content = "".join([l.strip() for l in lines if not l.startswith(">")])
            
        seq_style = ParagraphStyle('SeqStyle', parent=styles['Normal'], fontSize=10, fontName='Courier', leading=7)
        Story.append(Paragraph(seq_content, seq_style))
    except Exception:
        Story.append(Paragraph("Erreur lors de l'extraction de la séquence.", normal_style))
        
    Story.append(PageBreak())
    
    Story.append(Paragraph("TRAÇABILITÉ DÉTAILLÉE : BASE WESTERDIJK (KNAW)", subtitle_style))
    Story.append(Paragraph("Liste des meilleurs alignements (Ordre original de la base KNAW).", normal_style))
    Story.append(Spacer(1, 0.5*cm))
    
    if knaw_metrics["hits"]:
        Story.append(create_hits_table(knaw_metrics["hits"]))
    else:
        Story.append(Paragraph("Aucun hit détaillé.", normal_style))
        
    doc.build(Story, onFirstPage=add_footer_champis, onLaterPages=add_footer_champis)