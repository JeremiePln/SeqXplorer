import os
from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from datetime import datetime

def get_clinical_conclusion(summary_16s):
    if not summary_16s:
        return "Aucune identification significative (Aucun hit NCBI)."
    
    best_hits = sorted(summary_16s, key=lambda x: x["Max_Identity"], reverse=True)
    max_id = best_hits[0]["Max_Identity"]
    top_species = [s["Species"] for s in best_hits if s["Max_Identity"] == max_id]
    genus = top_species[0].split()[0] if top_species else "Inconnu"
    
    if max_id == 100.0:
        if len(top_species) > 1:
            return f"<b>Identification au genre {genus}</b> : Multiples espèces à 100% ({', '.join(top_species)}). Impossible de trancher de manière univoque."
        else:
            return f"<b>Identification à l'espèce/sous-espèce : {top_species[0]}</b> (100% d'identité)"
            
    elif max_id >= 99.0:
        if len(top_species) > 1:
            return f"<b>Identification au genre {genus}</b> : Multiples espèces significatives ex-æquo à {max_id}% ({', '.join(top_species)}). L'automate ne peut pas trancher de manière univoque."
        else:
            return f"<b>Identification à l'espèce : {top_species[0]}</b> ({max_id}% d'identité)"
            
    elif max_id >= 97.0:
        return f"<b>Identification au genre : {genus} spp.</b> (Meilleure identité à {max_id}%, insuffisant pour l'espèce)"
        
    else:
        return f"<b>Identification incertaine</b> (Identité maximale < 97% : {max_id}%)"

def get_header_table(styles):
    """Génère l'en-tête CHU réutilisable pour le haut de page"""
    try:
        global_root = Path(__file__).resolve().parent.parent.parent.parent
    except Exception:
        global_root = Path(__file__).resolve().parent.parent
    logo_path = global_root / "ressources" / "logo_chu.png"
    
    if logo_path.exists():
        logo_img = Image(str(logo_path), width=2.8*cm, height=1.7*cm)
    else:
        logo_img = Paragraph("<b>CHU Liege</b>", styles["Normal"])

    header_title_style = ParagraphStyle('HeaderTitle', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=16, textColor=colors.black, alignment=0)
    title_p = Paragraph("RAPPORT DE TAXONOMIE BACTÉRIENNE 16S", header_title_style)

    header_table = Table([[logo_img, title_p]], colWidths=[3*cm, 14*cm])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LINEBELOW', (0,0), (-1,-1), 2, colors.darkblue),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
    ]))
    return header_table

def create_qc_box(qc_metrics, styles):
    """Crée l'encadré dynamique de contrôle qualité du séquençage"""
    f_q20 = qc_metrics.get("f_q20", 0)
    r_q20 = qc_metrics.get("r_q20", 0)
    f_avg = qc_metrics.get("f_avg_phred", 0)
    r_avg = qc_metrics.get("r_avg_phred", 0)
    conf_rate = qc_metrics.get("conflict_rate", 0)
    conf_count = qc_metrics.get("conflicts", 0)
    
    is_red = f_q20 < 60 or r_q20 < 60 or conf_rate > 5.0
    is_orange = (60 <= f_q20 <= 80) or (60 <= r_q20 <= 80) or (2.0 <= conf_rate <= 5.0)
    
    if is_red:
        title = "🛑 ALERTE QUALITÉ : SOUPÇON DE CONTAMINATION / BRUIT"
        bg_color = colors.HexColor("#fdf2f2")
        border_color = colors.red
        note = "Note : Les résultats taxonomiques ci-dessous peuvent être biaisés par une séquence polymicrobienne. Vérification manuelle recommandée."
    elif is_orange:
        title = "⚠️ QUALITÉ MOYENNE : SÉQUENCE BRUITÉE"
        bg_color = colors.HexColor("#fff8e6")
        border_color = colors.orange
        note = "Note : Qualité suboptimale détectée. À interpréter avec précaution."
    else:
        title = "✅ QUALITÉ SÉQUENÇAGE : OPTIMALE"
        bg_color = colors.HexColor("#f0fdf4")
        border_color = colors.green
        note = ""

    content = [
        Paragraph(f"<b>{title}</b>", styles["Normal"]),
        Paragraph(f"• F : Q20 = {f_q20:.1f}% (Phred moy: {f_avg:.1f}) | R : Q20 = {r_q20:.1f}% (Phred moy: {r_avg:.1f})", styles["Normal"]),
        Paragraph(f"• Conflits F/R résolus dans le chevauchement : {conf_count} ({conf_rate:.1f}%)", styles["Normal"])
    ]
    if note:
        content.append(Paragraph(f"<i>{note}</i>", ParagraphStyle("small_i", parent=styles["Normal"], fontSize=8, textColor=colors.darkgray)))
    
    t = Table([[c] for c in content], colWidths=[17*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), bg_color),
        ('BOX', (0,0), (-1,-1), 1.5, border_color),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    return t

def create_summary_table(summary_data):
    data = [["Bactérie (Genre Espèce)", "Identité Max (%)", "Occurence(s)"]]
    for item in summary_data:
        data.append([item["Species"], f"{item['Max_Identity']}%", str(item["Occurrences"])])
        
    t = Table(data, colWidths=[8*cm, 4*cm, 4*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#28a745")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0,0), (-1,0), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
    ]))
    return t

def create_hits_table(hits_data):
    styles = getSampleStyleSheet()
    small_text_style = ParagraphStyle("SmallText", parent=styles["Normal"], fontSize=6, leading=7, textColor=colors.black)
    data = [["Nom complet de la souche", "% Identité", "Query Cover", "E-value", "Accession"]]
    
    for h in hits_data:
        formatted_e_value = "0.0" if h['E_value'] == 0 else f"{h['E_value']:.2e}"
        data.append([Paragraph(h["Name"], small_text_style), f"{h['Identity']}%", f"{h['QueryCover']}%", formatted_e_value, h["Accession"]])
        
    t = Table(data, colWidths=[10*cm, 1.8*cm, 1.8*cm, 1.5*cm, 2.2*cm], repeatRows=1) 
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#343a40")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (1,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.lightgrey),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 3),
    ]))
    return t

def add_footer_16s(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica-Oblique', 9)
    canvas.setFillColor(colors.gray)
    date_str = datetime.now().strftime("%d/%m/%Y")
    
    # Page 1 et 2 = SeqXplorer, Page 3 et + = BLAST
    if doc.page <= 2:
        text = f"Rapport généré automatiquement par SeqXplorer le {date_str}."
    else:
        text = f"Tableau de traçabilité extrait depuis BLASTn le {date_str}."
        
    # A4[0] est la largeur de la page. Divisé par 2, on est au centre exact.
    canvas.drawCentredString(A4[0] / 2.0, 1.5 * cm, text)
    canvas.restoreState()
    
def generate_final_report(patient_id, qc_metrics, blast_metrics, output_dir):
    out_path = Path(output_dir)
    final_report_path = out_path / f"Rapport_Final_{patient_id}.pdf"
    
    doc = SimpleDocTemplate(str(final_report_path), pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    subtitle_style = styles["Heading2"]
    subtitle_style.textColor = colors.darkblue
    normal_style = styles["Normal"]
    
    Story = [] 
    
    # ================== PAGE 1 ==================
    Story.append(get_header_table(styles))
    Story.append(Spacer(1, 1*cm))
    
    # 1. Infos générales
    Story.append(Paragraph("INFORMATIONS DE L'ÉCHANTILLON", subtitle_style))
    Story.append(Paragraph(f"<b>Identifiant (Run/Patient) :</b> {patient_id}", normal_style))
    Story.append(Paragraph(f"<b>Longueur du Consensus soumis au BLAST :</b> {qc_metrics.get('len_consensus', 0)} pb", normal_style))
    Story.append(Spacer(1, 0.5*cm))
    
    # 2. Encadré Qualité
    Story.append(Paragraph("CONTRÔLE QUALITÉ DU SÉQUENÇAGE", subtitle_style))
    Story.append(create_qc_box(qc_metrics, styles))

    Story.append(Spacer(1, 0.2*cm))
    legend_style = ParagraphStyle("ThresholdLegend", parent=styles["Normal"], fontSize=8, leading=10, textColor=colors.darkgray)
    
    Story.append(Paragraph("<i><b>Seuils d'interprétation :</b></i>", legend_style))
    Story.append(Paragraph("<i>• <b>Qualité Optimale (Vert)</b> : Q20 > 80% | Phred moyen > 30 | Conflits < 2%</i>", legend_style))
    Story.append(Paragraph("<i>• <b>Qualité Moyenne (Orange)</b> : Q20 entre 60% et 80% | Phred moyen entre 20 et 30 | Conflits entre 2% et 5%</i>", legend_style))
    Story.append(Paragraph("<i>• <b>Qualité Basse (Rouge)</b> : Q20 < 60% | Phred moyen < 20 | Conflits > 5%</i>", legend_style))
    
    Story.append(Spacer(1, 0.5*cm))
    
    # 3. Conclusions Cliniques
    Story.append(Paragraph("CONCLUSIONS CLINIQUES", subtitle_style))
    
    # Conclusion 16S
    conc_16s = get_clinical_conclusion(blast_metrics["16S"]["summary"])
    t_16s = Table([[Paragraph("<b>Conclusion Base 16S rRNA :</b>", styles["Normal"])], [Paragraph(conc_16s, styles["Normal"])]], colWidths=[17*cm])
    t_16s.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f8f9fa")), ('BOX', (0,0), (-1,-1), 2, colors.darkred), ('PADDING', (0,0), (-1,-1), 6)]))
    Story.append(t_16s)
    Story.append(Spacer(1, 0.3*cm))
    
    # Conclusion nt
    conc_nt = get_clinical_conclusion(blast_metrics["nt"]["summary"])
    t_nt = Table([[Paragraph("<b>Conclusion Base Nucleotides (nr/nt) :</b>", styles["Normal"])], [Paragraph(conc_nt, styles["Normal"])]], colWidths=[17*cm])
    t_nt.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#f8f9fa")), ('BOX', (0,0), (-1,-1), 2, colors.darkred), ('PADDING', (0,0), (-1,-1), 6)]))
    Story.append(t_nt)
    
    Story.append(PageBreak())
    
    # ================== PAGE 2 ==================
    Story.append(get_header_table(styles))
    Story.append(Spacer(1, 0.5*cm))

    Story.append(Paragraph("INFORMATIONS DE L'ÉCHANTILLON", subtitle_style))
    Story.append(Paragraph(f"<b>Identifiant (Run/Patient) :</b> {patient_id}", normal_style))
    Story.append(Paragraph(f"<b>Longueur du Consensus soumis au BLAST :</b> {qc_metrics.get('len_consensus', 0)} pb", normal_style))
    Story.append(Spacer(1, 0.5*cm))
    
    Story.append(Paragraph("SYNTHÈSE DES ESPÈCES DOMINANTES (Top 5)", subtitle_style))
    Story.append(Spacer(1, 0.3*cm))
    
    Story.append(Paragraph("<i>Base de données : 16S Ribosomal RNA</i>", normal_style))
    Story.append(Spacer(1, 0.2*cm))
    if blast_metrics["16S"]["summary"]:
        Story.append(create_summary_table(blast_metrics["16S"]["summary"]))
    else:
        Story.append(Paragraph("Aucun résultat trouvé.", normal_style))
    Story.append(Spacer(1, 0.8*cm))
    
    Story.append(Paragraph("<i>Base de données de vérification : Nucléotides (nr/nt)</i>", normal_style))
    Story.append(Spacer(1, 0.2*cm))
    if blast_metrics["nt"]["summary"]:
        Story.append(create_summary_table(blast_metrics["nt"]["summary"]))
    else:
        Story.append(Paragraph("Aucun résultat trouvé.", normal_style))
    Story.append(Spacer(1, 0.8*cm))

    Story.append(Paragraph("SÉQUENCE CONSENSUS GÉNÉRÉE PAR SEQXPLORER VIA BIOPYTHON :", subtitle_style))
    try:
        with open(qc_metrics["consensus_path"], "r") as f:
            lines = f.readlines()
            seq_content = "".join([l.strip() for l in lines if not l.startswith(">")])
        seq_style = ParagraphStyle('SeqStyle', parent=styles['Normal'], fontSize=6, fontName='Courier', leading=9)
        Story.append(Paragraph(seq_content, seq_style))
    except Exception:
        Story.append(Paragraph("Erreur lors de l'extraction de la séquence.", normal_style))
        
    Story.append(PageBreak())
    
    # ================== PAGES 3 ET + ==================
    Story.append(Paragraph("TRAÇABILITÉ DÉTAILLÉE : BASE 16S RIBOSOMAL RNA", subtitle_style))
    Story.append(Paragraph("Les 100 meilleurs alignements trouvés par l'algorithme NCBI BLASTn.", normal_style))
    Story.append(Spacer(1, 0.5*cm))
    
    if blast_metrics["16S"]["hits"]:
        Story.append(create_hits_table(blast_metrics["16S"]["hits"]))
    else:
        Story.append(Paragraph("Aucun hit détaillé.", normal_style))
        
    Story.append(PageBreak())
    
    Story.append(Paragraph("TRAÇABILITÉ DÉTAILLÉE : BASE NR/NT", subtitle_style))
    Story.append(Paragraph("Les 100 meilleurs alignements trouvés par l'algorithme NCBI BLASTn.", normal_style))
    Story.append(Spacer(1, 0.5*cm))
    
    if blast_metrics["nt"]["hits"]:
        Story.append(create_hits_table(blast_metrics["nt"]["hits"]))
    else:
        Story.append(Paragraph("Aucun hit détaillé.", normal_style))
        
    doc.build(Story, onFirstPage=add_footer_16s, onLaterPages=add_footer_16s)
    
    return str(final_report_path)