import streamlit as st
import os
import shutil
import sys
import asyncio
from pathlib import Path
import time

# Correctif asynchrone Windows
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from app_taxonomie_16s.styles import apply_shared_styles, draw_sidebar
import app_taxonomie_16s.core_modules.pairing_16s as pairing_16s
import app_taxonomie_16s.core_modules.pipeline_16s as pipeline_16s
import app_taxonomie_16s.core_modules.blast_16s as blast_16s
import app_taxonomie_16s.core_modules.report_16s as report_16s

# --- Style CSS pour encadrer les champs ---
st.markdown("""
    <style>
    div[data-testid="stTextInput"] > div { border: 1px solid #000000 !important; border-radius: 4px; }
    div[data-testid="stFileUploader"] > div { border: 1px solid #000000 !important; border-radius: 4px; }
    </style>
""", unsafe_allow_html=True)

st.set_page_config(page_title="Taxonomie 16S - Traitement", page_icon="🧬", layout="wide")

apply_shared_styles()
draw_sidebar()

# ==========================================
# 🛑 GESTION D'ÉTAT : VERROUILLAGE ET ARRÊT
# ==========================================
if "stop_requested" not in st.session_state:
    st.session_state.stop_requested = False
if "is_running" not in st.session_state:
    st.session_state.is_running = False

def stop_analysis():
    """Callback appelé instantanément lors du clic sur le bouton Stop"""
    st.session_state.stop_requested = True
    st.session_state.analyze_clicked = False
    st.session_state.is_running = False

# --- INTERFACE D'INTERRUPTION ET DE NETTOYAGE ---
if st.session_state.stop_requested:
    st.error("⚠️ L'analyse a été interrompue manuellement par l'utilisateur.")
    
    # Nettoyage automatique du patient en cours (incomplet)
    pat_dir = st.session_state.get("current_patient_dir")
    if pat_dir and Path(pat_dir).exists():
        shutil.rmtree(pat_dir, ignore_errors=True)
        
    # Nettoyage du dossier des inputs temporaires
    tmp_dir = st.session_state.get("current_temp_dir")
    if tmp_dir and Path(tmp_dir).exists():
        shutil.rmtree(tmp_dir, ignore_errors=True)
        
    st.info("💡 Les patients qui avaient été traités jusqu'au bout ont été sauvegardés. Le patient qui était en cours de traitement a été supprimé pour éviter la corruption de données.")
    
    col_del1, col_del2 = st.columns(2)
    with col_del1:
        if st.button("🗑️ Supprimer TOUT le Run (Repartir à zéro)", type="primary"):
            run_dir = st.session_state.get("current_run_dir")
            if run_dir and Path(run_dir).exists():
                shutil.rmtree(run_dir, ignore_errors=True)
            st.session_state.stop_requested = False
            st.success("Run complètement supprimé. L'environnement est de nouveau propre.")
            time.sleep(2)
            st.rerun()
    with col_del2:
        if st.button("Conserver les patients terminés et fermer"):
            st.session_state.stop_requested = False
            st.rerun()
            
    st.stop() # Empêche d'afficher le reste de la page pendant l'interruption

# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
RESULTS_DIR = BASE_DIR.parent / "Résultats_SeqXplorer" / "Résultats_16S"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

EMAIL_FILE = Path(__file__).resolve().parent.parent / "email_config.txt"

st.markdown(
    """<style>div[data-testid="stSelectbox"] input { caret-color: transparent !important; pointer-events: none !important; }</style>""",
    unsafe_allow_html=True
)

st.title("⚙️ Traitement & Taxonomie Automatisée 16S")
st.info("ℹ️ **Information NCBI :** Les serveurs mondiaux du NCBI exigent une adresse e-mail valide pour soumettre des requêtes automatisées BLAST.")

current_email = ""
if EMAIL_FILE.exists():
    with open(EMAIL_FILE, "r") as f:
        current_email = f.read().strip()

# Verrou de l'UI
is_run = st.session_state.is_running

user_email = st.text_input("📧 Adresse e-mail :", value=current_email, disabled=is_run)

if user_email and user_email != current_email and not is_run:
    with open(EMAIL_FILE, "w") as f:
        f.write(user_email.strip())

analyse_name = st.text_input('📝 Indiquer le nom du Run (Ne pas mettre de "/") :', disabled=is_run)

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0

uploaded_files = st.file_uploader(
    "Glissez/déposez tous vos fichiers .ab1 ici", 
    accept_multiple_files=True, 
    type=['ab1'],
    key=f"uploader_{st.session_state.uploader_key}",
    disabled=is_run
)

if st.button("🗑️ Effacer tous les fichiers importés", disabled=is_run):
    st.session_state.uploader_key += 1
    st.session_state.analyze_clicked = False
    st.rerun()

can_run = bool(uploaded_files) and bool(analyse_name) and bool(user_email)

if st.button("Lancer l'analyse taxonomique", type="primary", disabled=(not can_run or is_run)):
    st.session_state.analyze_clicked = True
    st.session_state.is_running = True
    st.session_state.ignore_orphans = False
    st.session_state.erreurs_pipeline = []
    st.rerun() # Force le rechargement pour verrouiller l'UI instantanément

if st.session_state.get("analyze_clicked", False):
    
    # Affichage du bouton STOP dynamique au-dessus des barres de progression
    stop_container = st.empty()
    with stop_container:
        st.button("🛑 STOPPER L'ANALYSE EN COURS", on_click=stop_analysis, type="primary")
        
    input_temp_dir = Path(f"Temp_Inputs_{analyse_name}")
    input_temp_dir.mkdir(exist_ok=True)
    st.session_state.current_temp_dir = str(input_temp_dir)
    
    for file in uploaded_files:
        with open(input_temp_dir / file.name, "wb") as f:
            f.write(file.getbuffer())
            
    valid_pairs, orphans, _ = pairing_16s.scan_directory(input_temp_dir)
    output_base_dir = RESULTS_DIR / f"Résultat_{analyse_name}"
    st.session_state.current_run_dir = str(output_base_dir)
    
    if orphans and not st.session_state.get("ignore_orphans", False):
        st.error(f"⚠️ Anomalie : {len(orphans)} fichier(s) orphelin(s) détecté(s) !")
        for orphelin in orphans:
            st.write(f"- {orphelin}")
        st.warning("Veuillez vérifier vos fichiers d'entrée.")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Continuer sans les orphelins"):
                st.session_state.ignore_orphans = True
                st.rerun()
        with col2:
            if st.button("Annuler le traitement"):
                st.session_state.analyze_clicked = False
                st.session_state.is_running = False
                shutil.rmtree(input_temp_dir, ignore_errors=True)
                st.rerun()
        st.stop()
            
    st.success(f"✅ Appairage réussi. {len(valid_pairs)} patient(s) identifié(s).")
    
    timer_text = st.empty()
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    paths_dict = pairing_16s.create_output_tree(valid_pairs, output_base_dir)

    start_time = time.time()
    for i, (patient_id, files) in enumerate(valid_pairs.items()):
        # Enregistrement du patient en cours (crucial pour le nettoyage du bouton STOP)
        out_dir = paths_dict[patient_id]
        st.session_state.current_patient_dir = str(out_dir.parent)
        
        status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Nettoyage et Consensus...")
        
        file_f = files['f']
        file_r = files['r']
        
        qc_metrics = pipeline_16s.process_pair(patient_id, file_f, file_r, out_dir)
        
        if qc_metrics["status"] == "success":
            status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Soumission BLAST NCBI (Veuillez patienter...)")
            
            blast_metrics = blast_16s.run_blast_patient(qc_metrics["consensus_path"], user_email, patient_id)
            
            if blast_metrics["status"] == "success":
                status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Édition du Rapport Clinique...")
                report_16s.generate_final_report(patient_id, qc_metrics, blast_metrics, out_dir.parent)
            else:
                 st.session_state.erreurs_pipeline.append(f"BLAST NCBI [{patient_id}] : {blast_metrics['error_msg']}")
        else:
            st.session_state.erreurs_pipeline.append(f"Contrôle Qualité [{patient_id}] : {qc_metrics['error_msg']}")
            
        progress_bar.progress((i + 1) / len(valid_pairs))

    end_time = time.time()
    duree = int(end_time - start_time)
    
    hours, reste = divmod(duree, 3600)
    mins, secs = divmod(reste, 60)
    
    if hours > 0:
        timer_text.info(f"⏱️ Temps total de traitement : {hours} h {mins} min et {secs} s")
    else:
        timer_text.info(f"⏱️ Temps total de traitement : {mins} min et {secs} s")
    
    status_text.text("🎉 Run d'analyse taxonomique complété !")
    shutil.rmtree(input_temp_dir, ignore_errors=True)
    
    if st.session_state.erreurs_pipeline:
        with st.expander(f"⚠️ {len(st.session_state.erreurs_pipeline)} erreur(s) rencontrée(s)", expanded=False):
            for err in st.session_state.erreurs_pipeline:
                st.write(f"- 🚩 {err}")
    
    # FIN DU RUN : Réinitialisation propre
    st.session_state['last_analyzed_run'] = output_base_dir.name
    st.session_state.analyze_clicked = False 
    st.session_state.is_running = False
    st.session_state.current_temp_dir = None
    st.session_state.current_patient_dir = None
    
    stop_container.empty() # Fait disparaître le bouton STOP
    
    st.divider()
    col1, col_center, col3 = st.columns([2, 2, 2])
    with col_center:
        st.page_link("app_taxonomie_16s/pages/2_Resultats_16s.py", label="Accéder aux Rapports Cliniques", icon="📂")