import time
import subprocess
import os
import csv
import re
import logging
import traceback
import shutil
from pathlib import Path
from Bio.Blast import NCBIWWW, NCBIXML
from collections import defaultdict

def setup_logger(patient_id, log_file_path):
    """Initialise un logger spécifique pour le patient qui écrit dans un fichier .log"""
    logger = logging.getLogger(f"Logger_{patient_id}")
    logger.setLevel(logging.DEBUG)
    
    if not logger.handlers:
        fh = logging.FileHandler(log_file_path, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        
    return logger

def parse_blast_record(blast_record):
    hits = []
    query_len = blast_record.query_length

    for alignment in blast_record.alignments:
        for hsp in alignment.hsps:
            ident_pct = (hsp.identities / hsp.align_length) * 100 if hsp.align_length > 0 else 0
            q_span = hsp.query_end - hsp.query_start + 1
            query_cover = (q_span / query_len) * 100 if query_len > 0 else 0

            raw_title = alignment.title
            parts = raw_title.split('|')
            clean_name = parts[-1].strip() if len(parts) > 1 else raw_title

            hit_data = {
                "Accession": alignment.accession,
                "Name": clean_name,
                "RawTitle": raw_title,
                "Identity": round(ident_pct, 2),
                "QueryCover": round(query_cover, 2),
                "E_value": hsp.expect
            }
            hits.append(hit_data)
            break
        if len(hits) >= 100:
            break
    return hits

def summarize_hits(hits):
    species_stats = defaultdict(list)
    for h in hits:
        clean_name = re.sub(r"[\[\]\']", "", h["Name"])
        words = clean_name.split()
        sp_name = f"{words[0]} {words[1]}" if len(words) >= 2 else words[0]
        species_stats[sp_name].append(h["Identity"])

    summary = []
    for sp_name, idents in species_stats.items():
        max_id = max(idents)
        summary.append({
            "Species": sp_name,
            "Max_Identity": max_id,
            "Occurrences": idents.count(max_id)
        })
    summary.sort(key=lambda x: (x["Max_Identity"], x["Occurrences"]), reverse=True)
    return summary[:5]

def load_emu_taxonomy(db_path, logger):
    tax_dict = {}
    tax_file = db_path.parent / "taxonomy.tsv"
    
    if not tax_file.exists():
        logger.warning("Fichier taxonomy.tsv introuvable. Les noms Emu ne seront pas traduits.")
        return tax_dict
        
    try:
        with open(tax_file, 'r', encoding='utf-8', errors='ignore') as f:
            reader = csv.reader(f, delimiter='\t')
            header = next(reader, None)
            
            if not header:
                return tax_dict
                
            tax_idx = header.index('tax_id') if 'tax_id' in header else 0
            species_idx = header.index('species') if 'species' in header else 1
            
            for row in reader:
                if len(row) > max(tax_idx, species_idx):
                    tax_id = row[tax_idx].strip()
                    species = row[species_idx].strip()
                    if species:
                        tax_dict[tax_id] = species
        logger.info(f"Dictionnaire taxonomique chargé avec {len(tax_dict)} entrées.")
    except Exception as e:
        logger.error(f"Erreur lors de la lecture du dictionnaire taxonomique : {str(e)}")
        
    return tax_dict

def run_local_blast_emu(consensus_fasta_path, logger):
    logger.info("--- Démarrage du module BLAST Local (Emu) ---")
    current_dir = Path(__file__).resolve().parent
    exe_name = "blastn.exe" if os.name == "nt" else "blastn"
    
    # 1. Recherche du binaire (Inclut désormais la vérification de l'installation système globale)
    system_blast = shutil.which(exe_name)
    possible_bin_paths = [
        current_dir.resolve().parents[2] / "bin" / exe_name,
        current_dir.resolve().parents[3] / "bin" / exe_name
    ]
    
    local_blastn = None
    if system_blast:
        local_blastn = Path(system_blast)
        logger.info(f"Exécutable BLAST trouvé dans le PATH système : {local_blastn}")
    else:
        for b_path in possible_bin_paths:
            if b_path.exists():
                local_blastn = b_path
                logger.info(f"Exécutable BLAST trouvé en local : {local_blastn}")
                break
            
    if not local_blastn:
        err = f"Exécutable {exe_name} introuvable."
        logger.error(err)
        return {"status": "error", "error_msg": err, "hits": [], "summary": []}
        
    # 2. Recherche de la base de données
    possible_db_paths = [
        current_dir.resolve().parents[2] / "databases" / "emu_db_blast" / "emu_db_blast",
        current_dir.resolve().parents[3] / "databases" / "emu_db_blast" / "emu_db_blast"
    ]
    
    db_file = None
    for p in possible_db_paths:
        if p.with_suffix(".nhr").exists() or Path(str(p) + ".nhr").exists():
            db_file = p.resolve()
            logger.info(f"Base de données Emu trouvée : {db_file}")
            break
            
    if not db_file:
        err = "Base Emu locale introuvable."
        logger.error(err)
        return {"status": "error", "error_msg": err, "hits": [], "summary": []}
    
    query_path = Path(consensus_fasta_path).resolve()
    clean_fasta_temp = query_path.parent / "temp_clean_query.fasta"
    xml_output_temp = query_path.parent / "temp_blast_emu.xml"
    
    try:
        # Nettoyage de l'en-tête
        logger.info("Nettoyage de l'en-tête FASTA...")
        with open(query_path, "r", encoding="utf-8", errors="ignore") as f_in:
            lines = f_in.readlines()
            
        with open(clean_fasta_temp, "w", encoding="utf-8") as f_out:
            for line in lines:
                if line.startswith(">"):
                    f_out.write(">query_sequence\n")
                else:
                    f_out.write(line)

        cmd = [
            str(local_blastn),
            "-query", str(clean_fasta_temp),
            "-db", db_file.name,
            "-out", str(xml_output_temp),
            "-outfmt", "5",
            "-max_target_seqs", "100",
            "-perc_identity", "90"
        ]
        
        logger.info(f"Exécution de la commande BLAST : {' '.join(cmd)}")
        logger.info(f"Dossier de travail (CWD) : {db_file.parent}")
        
        # Exécution avec capture détaillée
        res = subprocess.run(cmd, cwd=db_file.parent, check=True, capture_output=True, text=True)
        
        logger.info("BLAST exécuté avec succès. Parsing du fichier XML...")
        with open(xml_output_temp, "r") as result_handle:
            blast_record = NCBIXML.read(result_handle)
            
        hits = parse_blast_record(blast_record)
        
        # Traduction taxonomique
        logger.info("Début de la traduction taxonomique des Hits...")
        tax_dict = load_emu_taxonomy(db_file, logger)
        
        for hit in hits:
            mapped = False
            raw_title = hit.get("RawTitle", hit["Name"])
            
            if tax_dict:
                numbers = [n for n in re.findall(r'\d+', raw_title) if 2 <= len(n) <= 8]
                numbers.sort(key=len, reverse=True)
                for num in numbers:
                    if num in tax_dict:
                        hit["Name"] = tax_dict[num]
                        mapped = True
                        break
                        
            if not mapped:
                clean_txt = re.sub(r'gnl\|[^\|]+\|\d+\s*', '', raw_title)
                clean_txt = re.sub(r'\[location=[^\]]+\]', '', clean_txt)
                match = re.search(r'\b([A-Z][a-z]+)\s+([a-z]+)\b', clean_txt)
                if match:
                    hit["Name"] = f"{match.group(1)} {match.group(2)}"
                else:
                    hit["Name"] = clean_txt
                    
        logger.info("Traitement Emu terminé avec succès.")
        return {
            "status": "success",
            "hits": hits,
            "summary": summarize_hits(hits)
        }
        
    except subprocess.CalledProcessError as e:
        stderr_txt = e.stderr.strip() if e.stderr else ""
        stdout_txt = e.stdout.strip() if e.stdout else ""
        
        # CAPTURE DU CRASH SILENCIEUX (DLL manquante ou Antivirus)
        if not stderr_txt and not stdout_txt:
            err_msg = f"Crash silencieux (Code de sortie: {e.returncode})."
        else:
            err_msg = stderr_txt or stdout_txt
            
        logger.error(f"Echec du processus BLAST. Sortie : {err_msg}")
        return {"status": "error", "error_msg": err_msg, "hits": [], "summary": []}
        
    except Exception as e:
        full_trace = traceback.format_exc()
        logger.error(f"Erreur système critique inattendue :\n{full_trace}")
        return {"status": "error", "error_msg": f"Erreur critique. Voir les logs pour plus de détails.", "hits": [], "summary": []}
    
    finally:
        if clean_fasta_temp.exists():
            clean_fasta_temp.unlink()
        if xml_output_temp.exists():
            xml_output_temp.unlink()

def run_blast_patient(consensus_fasta_path, email, patient_id):
    # Initialisation du Logger dans le dossier du patient
    out_dir = Path(consensus_fasta_path).parent
    log_file = out_dir / f"pipeline_{patient_id}.log"
    logger = setup_logger(patient_id, log_file)
    
    logger.info(f"========== NOUVELLE ANALYSE PATIENT : {patient_id} ==========")
    logger.info(f"Email NCBI configuré : {email}")
    logger.info(f"Fichier Consensus : {consensus_fasta_path}")
    
    NCBIWWW.email = email
    
    with open(consensus_fasta_path, "r") as f:
        sequence_data = "".join([line.strip() for line in f.readlines() if not line.startswith(">")])

    results = {
        "status": "success",
        "error_msg": "",
        "16S": {"summary": [], "hits": []},
        "nt": {"summary": [], "hits": []},
        "Emu_Curated": {"summary": [], "hits": []}
    }

    try:
        # 1. BLAST Local Emu
        emu_results = run_local_blast_emu(consensus_fasta_path, logger)
        
        if emu_results["status"] == "error":
            # On propage l'erreur avec les détails remontés par la sous-fonction
            raise Exception(f"{emu_results['error_msg']}")
            
        results["Emu_Curated"]["hits"] = emu_results["hits"]
        results["Emu_Curated"]["summary"] = emu_results["summary"]
        
        logger.info("Lancement de la requête NCBI 16S...")
        result_handle_16s = NCBIWWW.qblast("blastn", "rRNA_typestrains/prokaryotic_16S_ribosomal_RNA", sequence_data, hitlist_size=100, megablast="off", word_size=11)
        blast_record_16s = NCBIXML.read(result_handle_16s)
        hits_16s = parse_blast_record(blast_record_16s)
        results["16S"]["hits"] = hits_16s
        results["16S"]["summary"] = summarize_hits(hits_16s)
        
        logger.info("Requête 16S terminée. Pause de courtoisie de 5s...")
        time.sleep(5)

        logger.info("Lancement de la requête NCBI nr/nt...")
        result_handle_nt = NCBIWWW.qblast("blastn", "nt", sequence_data, hitlist_size=100, megablast="off", word_size=11)
        blast_record_nt = NCBIXML.read(result_handle_nt)
        hits_nt = parse_blast_record(blast_record_nt)
        results["nt"]["hits"] = hits_nt
        results["nt"]["summary"] = summarize_hits(hits_nt)
        logger.info("Requête nr/nt terminée avec succès.")
        
        logger.info("Analyse globale terminée avec succès.")
        
    except Exception as e:
        logger.error(f"Echec global de l'analyse pour le patient {patient_id} : {str(e)}")
        results["status"] = "error"
        results["error_msg"] = str(e)
        
    return results