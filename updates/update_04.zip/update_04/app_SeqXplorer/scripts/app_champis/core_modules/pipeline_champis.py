import logging
from pathlib import Path
from Bio import SeqIO, Align
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

def get_pipeline_logger(patient_id, output_dir):
    """Initialise un logger partagé pour le patient Champignon"""
    log_file = Path(output_dir).parent / f"pipeline_{patient_id}.log"
    logger = logging.getLogger(f"Logger_{patient_id}")
    logger.setLevel(logging.DEBUG)
    
    if not logger.handlers:
        fh = logging.FileHandler(log_file, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        
    return logger

def calculate_quality_metrics(record):
    quals = record.letter_annotations["phred_quality"]
    if not quals:
        return 0.0, 0
    q20_count = sum(1 for q in quals if q >= 20)
    avg_phred = sum(quals) / len(quals)
    return (q20_count / len(quals)) * 100, avg_phred

def trim_sanger(record, min_phred=10, window_size=5):
    quals = record.letter_annotations["phred_quality"]
    seq_len = len(quals)
    start, end = 0, seq_len
    
    for i in range(seq_len - window_size + 1):
        if sum(quals[i:i+window_size]) / window_size >= min_phred:
            start = i
            break
            
    for i in range(seq_len, window_size - 1, -1):
        if sum(quals[i-window_size:i]) / window_size >= min_phred:
            end = i
            break
            
    if start >= end:
        return record[0:0] 
        
    return record[start:end]

def generate_consensus(seq_f, seq_r):
    aligner = Align.PairwiseAligner()
    aligner.mode = 'local'
    aligner.match_score = 2
    aligner.mismatch_score = -1
    aligner.open_gap_score = -5
    aligner.extend_gap_score = -1
    
    alignments = aligner.align(str(seq_f.seq), str(seq_r.seq))
    
    try:
        best_alignment = alignments[0]
    except IndexError:
        raise ValueError("Aucun alignement trouvé ! Les séquences ne se chevauchent pas ou la qualité est insuffisante.")
    
    aln_f, aln_r = best_alignment[0], best_alignment[1]
    
    qual_f = seq_f.letter_annotations["phred_quality"]
    qual_r = seq_r.letter_annotations["phred_quality"]
    
    idx_f = best_alignment.aligned[0][0][0]
    idx_r = best_alignment.aligned[1][0][0]
    
    consensus = []
    overlap_len = 0
    conflicts = 0
    
    for b1, b2 in zip(aln_f, aln_r):
        if b1 == '-':
            consensus.append(b2)
            idx_r += 1
            continue
        elif b2 == '-':
            consensus.append(b1)
            idx_f += 1
            continue
            
        overlap_len += 1
        q_f = qual_f[idx_f]
        q_r = qual_r[idx_r]
        
        if b1 == b2:
            consensus.append(b1)
        else:
            conflicts += 1
            if q_f > q_r + 5:
                consensus.append(b1)
            elif q_r > q_f + 5:
                consensus.append(b2)
            else:
                consensus.append('N')
                
        idx_f += 1
        idx_r += 1
            
    return "".join(consensus), conflicts, overlap_len

def process_pair(patient_id, file_f, file_r, output_dir):
    logger = get_pipeline_logger(patient_id, output_dir)
    logger.info(f"========== DÉBUT TRAITEMENT PATIENT CHAMPIGNON : {patient_id} ==========")
    logger.info(f"Fichier Forward : {file_f.name}")
    logger.info(f"Fichier Reverse : {file_r.name}")
    
    record_f = SeqIO.read(file_f, "abi")
    record_r = SeqIO.read(file_r, "abi")
    
    qc_metrics = {
        "status": "success",
        "error_msg": "",
        "len_f_init": len(record_f),
        "len_r_init": len(record_r),
        "len_f_trim": 0,
        "len_r_trim": 0,
        "len_consensus": 0,
        "f_q20": 0.0, "f_avg_phred": 0.0,
        "r_q20": 0.0, "r_avg_phred": 0.0,
        "conflicts": 0,
        "overlap_len": 0,
        "conflict_rate": 0.0,
        "consensus_path": None
    }
    
    logger.info("Exécution du nettoyage (Trimming) des extrémités...")
    trimmed_f = trim_sanger(record_f, min_phred=10)
    trimmed_r = trim_sanger(record_r, min_phred=10)
    
    qc_metrics["len_f_trim"] = len(trimmed_f)
    qc_metrics["len_r_trim"] = len(trimmed_r)
    
    if len(trimmed_f) < 50 or len(trimmed_r) < 50:
        err = "Séquence trop courte après nettoyage (inférieure à 50 pb)."
        logger.error(err)
        qc_metrics["status"] = "error"
        qc_metrics["error_msg"] = err
        return qc_metrics 
        
    f_q20, f_avg = calculate_quality_metrics(trimmed_f)
    r_q20, r_avg = calculate_quality_metrics(trimmed_r)
    qc_metrics["f_q20"] = f_q20
    qc_metrics["f_avg_phred"] = f_avg
    qc_metrics["r_q20"] = r_q20
    qc_metrics["r_avg_phred"] = r_avg
    
    logger.info(f"Qualité F - Q20: {f_q20:.1f}%, Phred Moyen: {f_avg:.1f}")
    logger.info(f"Qualité R - Q20: {r_q20:.1f}%, Phred Moyen: {r_avg:.1f}")
    
    reversed_r = trimmed_r.reverse_complement()
    reversed_r.id = trimmed_r.id + "_reversed"
    
    logger.info("Alignement local et génération du Consensus en cours...")
    try:
        consensus_str, conflicts, overlap_len = generate_consensus(trimmed_f, reversed_r)
        qc_metrics["len_consensus"] = len(consensus_str)
        qc_metrics["conflicts"] = conflicts
        qc_metrics["overlap_len"] = overlap_len
        if overlap_len > 0:
            qc_metrics["conflict_rate"] = (conflicts / overlap_len) * 100
            
        logger.info(f"Consensus généré avec succès : {len(consensus_str)} pb.")
        logger.info(f"Chevauchement : {overlap_len} pb | Conflits résolus : {conflicts} ({(conflicts/overlap_len)*100 if overlap_len else 0:.1f}%)")
        
    except ValueError as e:
        logger.error(f"Échec de l'alignement : {str(e)}")
        qc_metrics["status"] = "error"
        qc_metrics["error_msg"] = str(e)
        return qc_metrics
        
    consensus_record = SeqRecord(Seq(consensus_str), id=f"Consensus_{patient_id}", description="Généré automatiquement par SeqXplorer Champis")
    out_path = Path(output_dir)
    
    SeqIO.write(trimmed_f, out_path / f"{patient_id}_F_trimmed.fasta", "fasta")
    SeqIO.write(reversed_r, out_path / f"{patient_id}_R_reversed.fasta", "fasta")
    
    final_path = out_path / f"{patient_id}_consensus.fasta"
    SeqIO.write(consensus_record, final_path, "fasta")
    
    qc_metrics["consensus_path"] = str(final_path)
    logger.info("Fichiers FASTA (Trimmed et Consensus) sauvegardés sur le disque.")
    
    return qc_metrics