import streamlit as st
import os
import shutil
import sys
import asyncio
import time
from pathlib import Path

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from app_champis.styles import apply_shared_styles, draw_sidebar
import app_champis.core_modules.pairing_champis as pairing_champis
import app_champis.core_modules.pipeline_champis as pipeline_champis
import app_champis.core_modules.bot_champis as bot_champis
import app_champis.core_modules.report_champis as report_champis

st.markdown("""
    <style>
    div[data-testid="stTextInput"] > div { border: 1px solid #000000 !important; border-radius: 4px; }
    div[data-testid="stFileUploader"] > div { border: 1px solid #000000 !important; border-radius: 4px; }
    </style>
""", unsafe_allow_html=True)

st.set_page_config(page_title="Champignons - Traitement", page_icon="🍄", layout="wide")

apply_shared_styles()
draw_sidebar()

# ==========================================
# 🛑 GESTION D'ÉTAT : VERROUILLAGE ET ARRÊT
# ==========================================
if "stop_requested" not in st.session_state:
    st.session_state.stop_requested = False
if "is_running" not in st.session_state:
    st.session_state.is_running = False

def stop_analysis():
    st.session_state.stop_requested = True
    st.session_state.analyze_clicked = False
    st.session_state.is_running = False

if st.session_state.stop_requested:
    st.error("⚠️ L'analyse a été interrompue manuellement par l'utilisateur.")
    
    pat_dir = st.session_state.get("current_patient_dir")
    if pat_dir and Path(pat_dir).exists():
        shutil.rmtree(pat_dir, ignore_errors=True)
        
    tmp_dir = st.session_state.get("current_temp_dir")
    if tmp_dir and Path(tmp_dir).exists():
        shutil.rmtree(tmp_dir, ignore_errors=True)
        
    st.info("💡 Les patients traités jusqu'au bout ont été sauvegardés. Le patient en cours a été supprimé pour éviter la corruption de données.")
    
    col_del1, col_del2 = st.columns(2)
    with col_del1:
        if st.button("🗑️ Supprimer TOUT le Run (Repartir à zéro)", type="primary"):
            run_dir = st.session_state.get("current_run_dir")
            if run_dir and Path(run_dir).exists():
                shutil.rmtree(run_dir, ignore_errors=True)
            st.session_state.stop_requested = False
            st.success("Run complètement supprimé. L'environnement est de nouveau propre.")
            time.sleep(2)
            st.rerun()
    with col_del2:
        if st.button("Conserver les patients terminés et fermer"):
            st.session_state.stop_requested = False
            st.rerun()
            
    st.stop()
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
TEMP_BASE_DIR = BASE_DIR / "Temp_Inputs"
RESULTS_BASE_DIR = BASE_DIR.parent / "Résultats_SeqXplorer" / "Résultats_Champis"

st.title("🍄 Traitement Automatisé : Champignons (KNAW)")
st.markdown("Importez vos séquences Sanger (.ab1) pour l'alignement automatisé sur la base de données Westerdijk (KNAW).")

is_run = st.session_state.is_running

col1, col2 = st.columns([1, 1])
with col1:
    analyse_name = st.text_input('📝 Indiquer le nom du Run (Ne pas mettre de "/") :', placeholder="Ex: Run_Champis_2026-05-28", disabled=is_run)

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0

st.markdown("### 📂 Importation des séquences (.ab1)")
uploaded_files = st.file_uploader(
    "Glissez-déposez l'ensemble des fichiers Forward et Reverse du run :", 
    type=["ab1"], 
    accept_multiple_files=True,
    key=f"uploader_{st.session_state.uploader_key}",
    disabled=is_run
)

if st.button("🗑️ Effacer tous les fichiers importés", disabled=is_run):
    st.session_state.uploader_key += 1
    st.session_state.analyze_clicked = False
    st.rerun()

st.divider()

if st.button("🚀 Lancer l'analyse du Run", type="primary", disabled=(not analyse_name or not uploaded_files or is_run)):
    st.session_state.analyze_clicked = True
    st.session_state.is_running = True
    st.session_state.erreurs_pipeline = []
    st.rerun()

if st.session_state.get("analyze_clicked", False):
    
    stop_container = st.empty()
    with stop_container:
        st.button("🛑 STOPPER L'ANALYSE EN COURS", on_click=stop_analysis, type="primary")
    
    input_temp_dir = TEMP_BASE_DIR / f"Temp_Inputs_{analyse_name}"
    input_temp_dir.mkdir(parents=True, exist_ok=True)
    st.session_state.current_temp_dir = str(input_temp_dir)
    
    for f in uploaded_files:
        file_path = input_temp_dir / f.name
        with open(file_path, "wb") as out_f:
            out_f.write(f.read())
            
    valid_pairs, orphans, _ = pairing_champis.scan_directory(input_temp_dir)
    
    output_base_dir = RESULTS_BASE_DIR / f"Résultat_{analyse_name}"
    output_base_dir.mkdir(parents=True, exist_ok=True)
    st.session_state.current_run_dir = str(output_base_dir)
    
    if orphans:
        st.error(f"⚠️ Anomalie : {len(orphans)} fichier(s) orphelin(s) ou illisible(s) détecté(s) !")
        with st.expander("Voir les fichiers ignorés"):
            for o in orphans:
                st.write(f"- {o}")
                
    if not valid_pairs:
        st.error("❌ Aucune paire valide n'a pu être reconstituée. Traitement annulé.")
        shutil.rmtree(input_temp_dir, ignore_errors=True)
        st.session_state.analyze_clicked = False
        st.session_state.is_running = False
        st.stop()
        
    st.success(f"✅ Appairage réussi. {len(valid_pairs)} patient(s) identifié(s).")
    
    output_paths = pairing_champis.create_output_tree(valid_pairs, output_base_dir)
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    timer_text = st.empty()
    
    start_time = time.time()
    
    for i, (patient_id, files) in enumerate(valid_pairs.items()):
        out_dir = output_paths[patient_id]
        st.session_state.current_patient_dir = str(out_dir.parent)
        
        status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Contrôle Qualité & Consensus...")
        
        file_f = files['f']
        file_r = files['r']
        
        qc_metrics = pipeline_champis.process_pair(patient_id, file_f, file_r, out_dir)
        
        if qc_metrics["status"] == "success":
            status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Alignement sur le bot KNAW...")
            knaw_metrics = bot_champis.fetch_knaw_alignment(qc_metrics["consensus_path"], patient_id)
            
            if knaw_metrics["status"] == "success":
                status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Édition du Rapport Clinique...")
                report_champis.generate_final_report(patient_id, qc_metrics, knaw_metrics, out_dir.parent)
            else:
                 st.session_state.erreurs_pipeline.append(f"KNAW Bot [{patient_id}] : {knaw_metrics['error_msg']}")
        else:
            st.session_state.erreurs_pipeline.append(f"Contrôle Qualité [{patient_id}] : {qc_metrics['error_msg']}")
            
        progress_bar.progress((i + 1) / len(valid_pairs))

    end_time = time.time()
    duree = int(end_time - start_time)
    hours, reste = divmod(duree, 3600)
    mins, secs = divmod(reste, 60)
    
    if hours > 0:
        timer_text.info(f"⏱️ Temps total de traitement : {hours} h {mins} min et {secs} s")
    else:
        timer_text.info(f"⏱️ Temps total de traitement : {mins} min et {secs} s")
    
    status_text.text("🎉 Run d'identification fongique complété !")
    
    shutil.rmtree(input_temp_dir, ignore_errors=True)
    
    if st.session_state.erreurs_pipeline:
        with st.expander(f"⚠️ {len(st.session_state.erreurs_pipeline)} erreur(s) rencontrée(s)", expanded=False):
            for err in st.session_state.erreurs_pipeline:
                st.write(f"- 🚩 {err}")
    
    st.session_state['last_analyzed_run'] = output_base_dir.name
    st.session_state.analyze_clicked = False 
    st.session_state.is_running = False
    st.session_state.current_temp_dir = None
    st.session_state.current_patient_dir = None
    
    stop_container.empty()
    
    st.divider()
    col1, col_center, col3 = st.columns([2, 2, 2])
    with col_center:
        st.page_link("app_champis/pages/2_Resultats_Champis.py", label="Accéder aux Rapports Cliniques", icon="📂")