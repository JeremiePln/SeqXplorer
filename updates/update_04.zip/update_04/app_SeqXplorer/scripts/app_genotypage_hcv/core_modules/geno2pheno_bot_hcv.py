import time
import random
import re
import logging
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

def setup_logger(patient_id, log_file_path):
    """Récupère le logger du patient pour y ajouter les logs du bot Web"""
    logger = logging.getLogger(f"Logger_{patient_id}")
    if not logger.handlers:
        fh = logging.FileHandler(log_file_path, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    return logger

def fetch_hcv_genotype(consensus_fasta_path, output_dir, patient_id):
    # Initialisation du Logger lié à ce patient
    log_file = Path(output_dir).parent / f"pipeline_{patient_id}.log"
    logger = setup_logger(patient_id, log_file)
    logger.info("--- Démarrage du Bot Playwright : Geno2Pheno HCV ---")
    
    qc_metrics = {
        "status": "success",
        "error_msg": "",
        "subtype": "Inconnu",
        "confidence": "0%",
        "pdf_path": None
    }
    
    try:
        with open(consensus_fasta_path, "r") as f:
            lines = f.readlines()
            sequence = "".join([line.strip() for line in lines if not line.startswith(">")])
        logger.info("Séquence consensus chargée en mémoire.")
    except Exception as e:
        err = f"Erreur de lecture du FASTA : {e}"
        logger.error(err)
        qc_metrics["status"] = "error"
        qc_metrics["error_msg"] = err
        return qc_metrics

    logger.info("Ouverture du navigateur Headless Chromium...")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True) 
        context = browser.new_context(accept_downloads=True)
        page = context.new_page()

        try:
            logger.info("Navigation vers le portail Geno2Pheno...")
            page.goto("https://hcv.geno2pheno.org/", timeout=60000)
            time.sleep(random.uniform(2.5, 5.0))

            logger.info("Injection de la séquence dans le formulaire...")
            textarea = page.locator("textarea").first
            textarea.fill(sequence)

            logger.info("Soumission du formulaire de Génotypage...")
            page.get_by_role("button", name="Go", exact=True).first.click()

            logger.info("Attente de la réponse du serveur (Maximum 2 minutes)...")
            page.wait_for_load_state("networkidle", timeout=120000)
            time.sleep(2) 
            
            page_text = page.locator("body").inner_text()
            
            logger.info("Extraction Regex des sous-types de l'UI...")
            match_subtype = re.search(r"Predicted subtype:\s*([1-7][a-z]).*?=\s*([\d.]+)%", page_text, re.IGNORECASE)
            
            if match_subtype:
                subtype_base = match_subtype.group(1).strip()
                qc_metrics["confidence"] = f"{match_subtype.group(2)}%"
                
                match_clade = re.search(r"Predicted clade of subtype:\s*([IV]+)", page_text, re.IGNORECASE)
                if match_clade:
                    clade = match_clade.group(1).strip()
                    qc_metrics["subtype"] = f"{subtype_base} clade {clade}"
                else:
                    qc_metrics["subtype"] = subtype_base
                    
                logger.info(f"Génotype détecté avec succès : {qc_metrics['subtype']} ({qc_metrics['confidence']})")
            else:
                logger.warning("Le bot n'a détecté aucun génotype pertinent dans la page de résultats.")
            
            logger.info("Déclenchement du téléchargement du rapport PDF source...")
            pdf_locator = page.get_by_text("PDF", exact=False).first
            
            with page.expect_download(timeout=30000) as download_info:
                pdf_locator.click()
            
            download = download_info.value
            out_path = Path(output_dir)
            pdf_final_path = out_path / f"{patient_id}_Geno2pheno.pdf"
            
            download.save_as(str(pdf_final_path))
            qc_metrics["pdf_path"] = str(pdf_final_path)
            logger.info("Rapport PDF Geno2Pheno téléchargé avec succès.")
            
        except PlaywrightTimeoutError:
            err = "Délai d'attente dépassé sur Geno2pheno (Timeout)."
            logger.error(err)
            qc_metrics["status"] = "error"
            qc_metrics["error_msg"] = err
        except Exception as e:
            err = f"Erreur Playwright inattendue : {str(e)}"
            logger.error(err)
            qc_metrics["status"] = "error"
            qc_metrics["error_msg"] = err
        finally:
            logger.info("Fermeture sécurisée du navigateur virtuel.")
            browser.close()

    return qc_metrics