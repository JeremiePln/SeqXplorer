import streamlit as st
import os
import shutil
import sys
import asyncio
from pathlib import Path
import time

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from app_genotypage_hcv.styles import apply_shared_styles, draw_sidebar
import app_genotypage_hcv.core_modules.pairing_hcv as pairing_hcv
import app_genotypage_hcv.core_modules.pipeline_hcv as pipeline_hcv
import app_genotypage_hcv.core_modules.geno2pheno_bot_hcv as geno2pheno_bot_hcv
import app_genotypage_hcv.core_modules.report_hcv as report_hcv

st.markdown("""
    <style>
    div[data-testid="stTextInput"] > div { border: 1px solid #000000 !important; border-radius: 4px; }
    div[data-testid="stFileUploader"] > div { border: 1px solid #000000 !important; border-radius: 4px; }
    </style>
""", unsafe_allow_html=True)

st.set_page_config(page_title="Génotypage Automatisé", page_icon="🧬", layout="wide")

apply_shared_styles()
draw_sidebar()

# ==========================================
# 🛑 GESTION D'ÉTAT : VERROUILLAGE ET ARRÊT
# ==========================================
if "stop_requested" not in st.session_state:
    st.session_state.stop_requested = False
if "is_running" not in st.session_state:
    st.session_state.is_running = False

def stop_analysis():
    st.session_state.stop_requested = True
    st.session_state.analyze_clicked = False
    st.session_state.is_running = False

if st.session_state.stop_requested:
    st.error("⚠️ L'analyse a été interrompue manuellement par l'utilisateur.")
    
    # Nettoyage automatique du patient en cours (supprime TOUT son dossier racine)
    pat_dir = st.session_state.get("current_patient_dir")
    if pat_dir and Path(pat_dir).exists():
        shutil.rmtree(pat_dir, ignore_errors=True)
        
    # Nettoyage du dossier des inputs temporaires
    tmp_dir = st.session_state.get("current_temp_dir")
    if tmp_dir and Path(tmp_dir).exists():
        shutil.rmtree(tmp_dir, ignore_errors=True)
        
    st.info("💡 Les patients traités jusqu'au bout ont été sauvegardés. Le patient en cours a été supprimé pour éviter la corruption de données.")
    
    col_del1, col_del2 = st.columns(2)
    with col_del1:
        if st.button("🗑️ Supprimer TOUT le Run (Repartir à zéro)", type="primary"):
            # Supprime intégralement le dossier du run (ex: Résultat_NomDuRun)
            run_dir = st.session_state.get("current_run_dir")
            if run_dir and Path(run_dir).exists():
                shutil.rmtree(run_dir, ignore_errors=True)
            st.session_state.stop_requested = False
            st.success("Run complètement supprimé. L'environnement est de nouveau propre.")
            time.sleep(2)
            st.rerun()
    with col_del2:
        if st.button("Conserver les patients terminés et fermer"):
            st.session_state.stop_requested = False
            st.rerun()
            
    st.stop()
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
RESULTS_DIR = BASE_DIR.parent / "Résultats_SeqXplorer" / "Résultats_HCV"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

st.markdown(
    """<style>div[data-testid="stSelectbox"] input { caret-color: transparent !important; pointer-events: none !important; }</style>""",
    unsafe_allow_html=True
)

st.title("⚙️ Traitement & Génotypage Automatisé")

is_run = st.session_state.is_running

analyse_name = st.text_input('📝 Indiquer le nom du Run (Ne pas mettre de "/"):', disabled=is_run)

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0

uploaded_files = st.file_uploader(
    "Glissez/déposez tous vos fichiers .ab1 ici", 
    accept_multiple_files=True, 
    type=['ab1'],
    key=f"uploader_{st.session_state.uploader_key}",
    disabled=is_run
)

if st.button("🗑️ Effacer tous les fichiers importés", disabled=is_run):
    st.session_state.uploader_key += 1
    st.session_state.analyze_clicked = False
    st.rerun()

can_run = bool(uploaded_files) and bool(analyse_name)

if st.button("Lancer l'analyse du Run", type="primary", disabled=(not can_run or is_run)):
    st.session_state.analyze_clicked = True
    st.session_state.is_running = True
    st.session_state.ignore_orphans = False
    st.session_state.erreurs_pipeline = []
    st.rerun()

if st.session_state.get("analyze_clicked", False):
    
    stop_container = st.empty()
    with stop_container:
        st.button("🛑 STOPPER L'ANALYSE EN COURS", on_click=stop_analysis, type="primary")
        
    input_temp_dir = Path(f"Temp_Inputs_{analyse_name}")
    input_temp_dir.mkdir(exist_ok=True)
    st.session_state.current_temp_dir = str(input_temp_dir)
    
    for file in uploaded_files:
        with open(input_temp_dir / file.name, "wb") as f:
            f.write(file.getbuffer())
            
    valid_pairs, orphans, _ = pairing_hcv.scan_directory(input_temp_dir)
    output_base_dir = RESULTS_DIR / f"Résultat_{analyse_name}"
    st.session_state.current_run_dir = str(output_base_dir)
    
    if orphans and not st.session_state.get("ignore_orphans", False):
        st.error(f"⚠️ Anomalie : {len(orphans)} fichier(s) orphelin(s) détecté(s) !")
        for orphelin in orphans:
            st.write(f"- {orphelin}")
        st.warning("Veuillez vérifier vos fichiers d'entrée.")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Continuer sans les orphelins"):
                st.session_state.ignore_orphans = True
                st.rerun()
        with col2:
            if st.button("Stopper le traitement"):
                st.session_state.analyze_clicked = False
                st.session_state.is_running = False
                shutil.rmtree(input_temp_dir, ignore_errors=True)
                st.rerun()
                
        st.stop()
            
    st.success(f"✅ Appairage réussi. {len(valid_pairs)} patient(s) identifié(s).")
    
    timer_text = st.empty()
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    paths_dict = pairing_hcv.create_output_tree(valid_pairs, output_base_dir)
    
    start_time = time.time()
    
    for i, (patient_id, files) in enumerate(valid_pairs.items()):
        # Cible bien la RACINE du dossier patient pour la suppression en cas d'interruption
        out_dir = paths_dict[patient_id]
        st.session_state.current_patient_dir = str(out_dir.parent)
        
        status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Nettoyage et Consensus...")
        
        file_f = files['f']
        file_r = files['r']
        
        qc_metrics = pipeline_hcv.process_pair(patient_id, file_f, file_r, out_dir)
        
        if qc_metrics["status"] == "success":
            status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Matching Geno2pheno...")
            g2p_metrics = geno2pheno_bot_hcv.fetch_hcv_genotype(qc_metrics["consensus_path"], out_dir, patient_id)
            
            if g2p_metrics["status"] == "success":
                status_text.text(f"Patient {patient_id} ({i+1}/{len(valid_pairs)}) : Édition du Rapport Final...")
                report_hcv.generate_final_report(patient_id, qc_metrics, g2p_metrics, out_dir.parent)
            else:
                 st.session_state.erreurs_pipeline.append(f"Geno2pheno [{patient_id}] : {g2p_metrics['error_msg']}")
        else:
            st.session_state.erreurs_pipeline.append(f"Contrôle Qualité [{patient_id}] : {qc_metrics['error_msg']}")
            
        progress_bar.progress((i + 1) / len(valid_pairs))

    end_time = time.time()
    duree = int(end_time - start_time)
    hours, reste = divmod(duree, 3600)
    mins, secs = divmod(reste, 60)
    
    if hours > 0:
        timer_text.info(f"⏱️ Temps total de traitement : {hours} h {mins} min et {secs} s")
    else:
        timer_text.info(f"⏱️ Temps total de traitement : {mins} min et {secs} s")
        
    status_text.text("🎉 Run d'analyse complété !")
    shutil.rmtree(input_temp_dir, ignore_errors=True)
    
    if st.session_state.erreurs_pipeline:
        with st.expander(f"⚠️ {len(st.session_state.erreurs_pipeline)} erreur(s) rencontrée(s)", expanded=False):
            for err in st.session_state.erreurs_pipeline:
                st.write(f"- 🚩 {err}")
    
    # FIN DU RUN : Réinitialisation
    st.session_state['last_analyzed_run'] = output_base_dir.name
    st.session_state.analyze_clicked = False 
    st.session_state.is_running = False
    st.session_state.current_temp_dir = None
    st.session_state.current_patient_dir = None
    
    stop_container.empty()
    
    st.divider()

    col1, col_center, col3 = st.columns([2, 2, 2])
    with col_center:
        st.page_link("app_genotypage_hcv/pages/2_Resultats.py", label="Accéder aux Rapports Cliniques", icon="📂")